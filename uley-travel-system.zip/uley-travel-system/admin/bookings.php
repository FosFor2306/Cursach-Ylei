<?php
session_start();
require_once '../config.php';
require_once '../includes/auth.php';

if (!isAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Получаем все бронирования
$bookings = $pdo->query("
    SELECT b.*, u.full_name as user_name, t.title as tour_title 
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN tours t ON b.tour_id = t.id
    ORDER BY b.created_at DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Все бронирования - Админ панель - Улей</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <?php include '../includes/header.php'; ?>
        
        <main>
            <h2>Все бронирования</h2>
            
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Клиент</th>
                        <th>Тур</th>
                        <th>Кол-во человек</th>
                        <th>Сумма</th>
                        <th>Статус</th>
                        <th>Дата создания</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($bookings as $booking): ?>
                    <tr>
                        <td><?php echo $booking['id']; ?></td>
                        <td><?php echo htmlspecialchars($booking['user_name']); ?></td>
                        <td><?php echo htmlspecialchars($booking['tour_title']); ?></td>
                        <td><?php echo $booking['persons_count']; ?></td>
                        <td><?php echo number_format($booking['total_price'], 0, ',', ' '); ?> ₽</td>
                        <td><?php echo $booking['status']; ?></td>
                        <td><?php echo date('d.m.Y H:i', strtotime($booking['created_at'])); ?></td>
                        <td>
    <a href="../booking_details.php?id=<?php echo $booking['id']; ?>" class="btn btn-sm btn-secondary">Подробнее</a>
    <a href="?delete=<?php echo $booking['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Удалить это бронирование?')">Удалить</a>
</td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </main>
        
        <?php include '../includes/footer.php'; ?>
    </div>
</body>
</html>