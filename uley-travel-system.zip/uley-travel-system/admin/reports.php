<?php
session_start();
require_once '../config.php';
require_once '../includes/auth.php';

if (!isAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Функция для получения структуры таблицы
function getTableStructure($table_name) {
    global $pdo;
    try {
        $stmt = $pdo->query("PRAGMA table_info($table_name)");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

// Функция для получения доступных колонок
function getTableColumns($table_name) {
    $structure = getTableStructure($table_name);
    $columns = [];
    foreach ($structure as $col) {
        $columns[] = $col['name'];
    }
    return $columns;
}

// Скачивание отчета
if (isset($_GET['download'])) {
    $report_id = intval($_GET['download']);
    $stmt = $pdo->prepare("SELECT * FROM reports WHERE id = ?");
    $stmt->execute([$report_id]);
    $report = $stmt->fetch();
    
    if ($report) {
        generateAndDownloadReport($report);
    }
}

// Генерация и скачивание отчета на лету
function generateAndDownloadReport($report) {
    global $pdo;
    
    $parameters = json_decode($report['parameters'], true);
    $report_type = $parameters['type'] ?? $report['report_type'];
    $period_start = $report['period_start'];
    $period_end = $report['period_end'];
    $format = $parameters['format'] ?? 'csv';
    
    // Получаем данные отчета
    $data = getReportData($report_type, $period_start, $period_end);
    
    // Генерируем файл в зависимости от формата
    switch ($format) {
        case 'excel':
            downloadAsExcel($data, $report['report_name'], $report_type);
            break;
        case 'json':
            downloadAsJson($data, $report['report_name'], $report_type);
            break;
        case 'pdf':
            downloadAsPdf($data, $report['report_name'], $report_type);
            break;
        case 'csv':
        default:
            downloadAsCsv($data, $report['report_name'], $report_type);
            break;
    }
    exit();
}

// Получение данных отчета - УНИВЕРСАЛЬНАЯ ВЕРСИЯ
function getReportData($type, $start, $end) {
    global $pdo;
    
    switch ($type) {
        case 'sales':
            return getSalesData($start, $end);
        case 'bookings':
            return getBookingsData($start, $end);
        case 'users':
            return getUsersData($start, $end);
        case 'tours':
            return getToursData($start, $end);
        default:
            return [];
    }
}

// Данные по продажам
function getSalesData($start, $end) {
    global $pdo;
    
    $data = [];
    
    try {
        // Проверяем существование таблицы bookings
        $bookings_columns = getTableColumns('bookings');
        
        if (empty($bookings_columns)) {
            return [['error' => 'Таблица bookings не найдена']];
        }
        
        // Основные поля для bookings
        $select_fields = ["b.id"];
        
        // Добавляем дату создания
        if (in_array('created_at', $bookings_columns)) {
            $select_fields[] = "DATE(b.created_at) as booking_date";
        } elseif (in_array('booking_date', $bookings_columns)) {
            $select_fields[] = "DATE(b.booking_date) as booking_date";
        }
        
        // Добавляем сумму
        if (in_array('total_price', $bookings_columns)) {
            $select_fields[] = "b.total_price";
        } elseif (in_array('price', $bookings_columns)) {
            $select_fields[] = "b.price";
        } elseif (in_array('amount', $bookings_columns)) {
            $select_fields[] = "b.amount";
        }
        
        // Добавляем статус
        if (in_array('status', $bookings_columns)) {
            $select_fields[] = "b.status";
        }
        
        // Проверяем и добавляем связь с турами
        $tours_columns = getTableColumns('tours');
        $has_tours = !empty($tours_columns) && in_array('tour_id', $bookings_columns);
        
        if ($has_tours) {
            // Ищем поле с названием тура
            $tour_name_field = 'name';
            if (!in_array('name', $tours_columns)) {
                if (in_array('title', $tours_columns)) {
                    $tour_name_field = 'title';
                } elseif (in_array('tour_name', $tours_columns)) {
                    $tour_name_field = 'tour_name';
                }
            }
            $select_fields[] = "t.$tour_name_field as tour_name";
        }
        
        // Проверяем и добавляем связь с пользователями
        $users_columns = getTableColumns('users');
        $has_users = !empty($users_columns) && in_array('user_id', $bookings_columns);
        
        if ($has_users) {
            // Ищем поле с именем пользователя
            $user_name_field = 'full_name';
            if (!in_array('full_name', $users_columns)) {
                if (in_array('username', $users_columns)) {
                    $user_name_field = 'username';
                } elseif (in_array('email', $users_columns)) {
                    $user_name_field = 'email';
                }
            }
            $select_fields[] = "u.$user_name_field as customer";
        }
        
        // Формируем SQL запрос
        $sql = "SELECT " . implode(", ", $select_fields) . " FROM bookings b";
        
        if ($has_tours) {
            $sql .= " LEFT JOIN tours t ON b.tour_id = t.id";
        }
        
        if ($has_users) {
            $sql .= " LEFT JOIN users u ON b.user_id = u.id";
        }
        
        // Определяем поле для фильтрации по дате
        $date_field = 'created_at';
        if (!in_array('created_at', $bookings_columns)) {
            if (in_array('booking_date', $bookings_columns)) {
                $date_field = 'booking_date';
            } elseif (in_array('date_created', $bookings_columns)) {
                $date_field = 'date_created';
            }
        }
        
        $sql .= " WHERE b.$date_field BETWEEN ? AND ?";
        
        // Фильтр по статусу продаж
        if (in_array('status', $bookings_columns)) {
            $sql .= " AND (b.status = 'confirmed' OR b.status = 'paid' OR b.status = 'completed' OR b.status = 'success' OR b.status IS NULL)";
        }
        
        $sql .= " ORDER BY b.$date_field DESC";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$start . ' 00:00:00', $end . ' 23:59:59']);
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        $data = [['error' => $e->getMessage()]];
    }
    
    return $data;
}

// Данные по бронированиям
function getBookingsData($start, $end) {
    global $pdo;
    
    $data = [];
    
    try {
        $bookings_columns = getTableColumns('bookings');
        
        if (empty($bookings_columns)) {
            return [['error' => 'Таблица bookings не найдена']];
        }
        
        $select_fields = ["b.id"];
        
        // Добавляем основные поля
        $basic_fields = [
            'created_at' => 'created_at',
            'booking_date' => 'booking_date',
            'check_in' => 'check_in',
            'check_out' => 'check_out',
            'total_price' => 'total_price',
            'price' => 'price',
            'amount' => 'amount',
            'status' => 'status',
            'payment_status' => 'payment_status',
            'guests' => 'guests',
            'persons' => 'persons'
        ];
        
        foreach ($basic_fields as $field => $alias) {
            if (in_array($field, $bookings_columns)) {
                $select_fields[] = "b.$field as $alias";
            }
        }
        
        // Связи с другими таблицами
        $tours_columns = getTableColumns('tours');
        $has_tours = !empty($tours_columns) && in_array('tour_id', $bookings_columns);
        
        if ($has_tours) {
            $tour_fields = ['name', 'title', 'tour_name'];
            foreach ($tour_fields as $field) {
                if (in_array($field, $tours_columns)) {
                    $select_fields[] = "t.$field as tour_name";
                    break;
                }
            }
        }
        
        $users_columns = getTableColumns('users');
        $has_users = !empty($users_columns) && in_array('user_id', $bookings_columns);
        
        if ($has_users) {
            $user_fields = ['full_name', 'username', 'email', 'phone'];
            foreach ($user_fields as $field) {
                if (in_array($field, $users_columns)) {
                    $select_fields[] = "u.$field as customer";
                    break;
                }
            }
        }
        
        // Формируем SQL
        $sql = "SELECT " . implode(", ", $select_fields) . " FROM bookings b";
        
        if ($has_tours) {
            $sql .= " LEFT JOIN tours t ON b.tour_id = t.id";
        }
        
        if ($has_users) {
            $sql .= " LEFT JOIN users u ON b.user_id = u.id";
        }
        
        // Определяем поле даты
        $date_field = 'created_at';
        if (!in_array('created_at', $bookings_columns)) {
            $date_fields = ['booking_date', 'date_created', 'created_date'];
            foreach ($date_fields as $field) {
                if (in_array($field, $bookings_columns)) {
                    $date_field = $field;
                    break;
                }
            }
        }
        
        $sql .= " WHERE b.$date_field BETWEEN ? AND ? ORDER BY b.$date_field DESC";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$start . ' 00:00:00', $end . ' 23:59:59']);
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        $data = [['error' => $e->getMessage()]];
    }
    
    return $data;
}

// Данные по пользователям
function getUsersData($start, $end) {
    global $pdo;
    
    $data = [];
    
    try {
        $users_columns = getTableColumns('users');
        
        if (empty($users_columns)) {
            return [['error' => 'Таблица users не найдена']];
        }
        
        $select_fields = ["u.id"];
        
        // Основные поля пользователей
        $user_fields = [
            'email' => 'email',
            'full_name' => 'full_name',
            'username' => 'username',
            'phone' => 'phone',
            'role' => 'role',
            'created_at' => 'created_at',
            'last_login' => 'last_login'
        ];
        
        foreach ($user_fields as $field => $alias) {
            if (in_array($field, $users_columns)) {
                if ($field == 'created_at') {
                    $select_fields[] = "DATE(u.created_at) as registration_date";
                } else {
                    $select_fields[] = "u.$field as $alias";
                }
            }
        }
        
        $sql = "SELECT " . implode(", ", $select_fields) . " FROM users u";
        
        // Определяем поле даты
        $date_field = 'created_at';
        if (!in_array('created_at', $users_columns)) {
            $date_fields = ['registration_date', 'date_created', 'created_date'];
            foreach ($date_fields as $field) {
                if (in_array($field, $users_columns)) {
                    $date_field = $field;
                    break;
                }
            }
        }
        
        if (in_array($date_field, $users_columns)) {
            $sql .= " WHERE u.$date_field BETWEEN ? AND ? ORDER BY u.$date_field DESC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$start . ' 00:00:00', $end . ' 23:59:59']);
        } else {
            $sql .= " ORDER BY u.id DESC LIMIT 1000";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
        }
        
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        $data = [['error' => $e->getMessage()]];
    }
    
    return $data;
}

// Данные по турам
function getToursData($start, $end) {
    global $pdo;
    
    $data = [];
    
    try {
        $tours_columns = getTableColumns('tours');
        
        if (empty($tours_columns)) {
            return [['error' => 'Таблица tours не найдена']];
        }
        
        $select_fields = ["t.id"];
        
        // Основные поля туров
        $tour_fields = [
            'name' => 'name',
            'title' => 'title',
            'description' => 'description',
            'price' => 'price',
            'duration' => 'duration',
            'location' => 'location',
            'destination' => 'destination',
            'available_slots' => 'available_slots',
            'max_participants' => 'max_participants',
            'created_at' => 'created_at'
        ];
        
        foreach ($tour_fields as $field => $alias) {
            if (in_array($field, $tours_columns)) {
                if ($field == 'created_at') {
                    $select_fields[] = "DATE(t.created_at) as created_date";
                } else {
                    $select_fields[] = "t.$field as $alias";
                }
            }
        }
        
        $sql = "SELECT " . implode(", ", $select_fields) . " FROM tours t";
        
        // Определяем поле даты
        $date_field = 'created_at';
        if (!in_array('created_at', $tours_columns)) {
            $date_fields = ['date_created', 'created_date', 'added_date'];
            foreach ($date_fields as $field) {
                if (in_array($field, $tours_columns)) {
                    $date_field = $field;
                    break;
                }
            }
        }
        
        if (in_array($date_field, $tours_columns)) {
            $sql .= " WHERE t.$date_field BETWEEN ? AND ? ORDER BY t.$date_field DESC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$start . ' 00:00:00', $end . ' 23:59:59']);
        } else {
            $sql .= " ORDER BY t.id DESC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
        }
        
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        $data = [['error' => $e->getMessage()]];
    }
    
    return $data;
}

// Скачивание как CSV
function downloadAsCsv($data, $report_name, $report_type) {
    $filename = sanitizeFileName($report_name) . '_' . date('Y-m-d_H-i') . '.csv';
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $output = fopen('php://output', 'w');
    fwrite($output, "\xEF\xBB\xBF"); // UTF-8 BOM
    
    if (!empty($data) && !isset($data[0]['error'])) {
        // Заголовки
        fputcsv($output, array_keys($data[0]), ';');
        
        // Данные
        foreach ($data as $row) {
            fputcsv($output, $row, ';');
        }
    } else {
        $error = isset($data[0]['error']) ? $data[0]['error'] : 'Нет данных для отчета';
        fputcsv($output, ['Ошибка', $error], ';');
    }
    
    fclose($output);
}

// Скачивание как Excel
function downloadAsExcel($data, $report_name, $report_type) {
    $filename = sanitizeFileName($report_name) . '_' . date('Y-m-d_H-i') . '.xls';
    
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    echo '<html xmlns:o="urn:schemas-microsoft-com:office:office"
          xmlns:x="urn:schemas-microsoft-com:office:excel"
          xmlns="http://www.w3.org/TR/REC-html40">
          <head>
          <meta charset="UTF-8">
          <!--[if gte mso 9]>
          <xml>
            <x:ExcelWorkbook>
              <x:ExcelWorksheets>
                <x:ExcelWorksheet>
                  <x:Name>' . htmlspecialchars($report_name) . '</x:Name>
                  <x:WorksheetOptions>
                    <x:DisplayGridlines/>
                  </x:WorksheetOptions>
                </x:ExcelWorksheet>
              </x:ExcelWorksheets>
            </x:ExcelWorkbook>
          </xml>
          <![endif]-->
          <style>
            table { border-collapse: collapse; width: 100%; }
            th { background-color: #4CAF50; color: white; padding: 8px; text-align: left; font-weight: bold; }
            td { border: 1px solid #ddd; padding: 6px; }
            tr:nth-child(even) { background-color: #f2f2f2; }
            .title { font-size: 18px; font-weight: bold; margin-bottom: 20px; }
            .info { margin-bottom: 15px; color: #666; }
          </style>
          </head>
          <body>';
    
    echo '<div class="title">' . htmlspecialchars($report_name) . '</div>';
    echo '<div class="info">Дата формирования: ' . date('d.m.Y H:i:s') . '</div>';
    
    if (!empty($data) && !isset($data[0]['error'])) {
        echo '<table>';
        echo '<thead><tr>';
        foreach (array_keys($data[0]) as $header) {
            echo '<th>' . htmlspecialchars($header) . '</th>';
        }
        echo '</tr></thead>';
        
        echo '<tbody>';
        foreach ($data as $row) {
            echo '<tr>';
            foreach ($row as $cell) {
                echo '<td>' . htmlspecialchars($cell) . '</td>';
            }
            echo '</tr>';
        }
        echo '</tbody></table>';
    } else {
        $error = isset($data[0]['error']) ? $data[0]['error'] : 'Нет данных для отчета';
        echo '<p style="color: red;">Ошибка: ' . htmlspecialchars($error) . '</p>';
    }
    
    echo '</body></html>';
}

// Скачивание как JSON
function downloadAsJson($data, $report_name, $report_type) {
    $filename = sanitizeFileName($report_name) . '_' . date('Y-m-d_H-i') . '.json';
    
    // Формируем структурированный JSON
    $json_data = [
        'report' => [
            'name' => $report_name,
            'type' => $report_type,
            'generated_at' => date('Y-m-d H:i:s'),
            'period' => [
                'start' => isset($_GET['period_start']) ? $_GET['period_start'] : date('Y-m-01'),
                'end' => isset($_GET['period_end']) ? $_GET['period_end'] : date('Y-m-d')
            ],
            'metadata' => [
                'total_records' => count($data),
                'format' => 'json',
                'version' => '1.0'
            ]
        ],
        'data' => $data
    ];
    
    // Добавляем статистику если есть данные
    if (!empty($data) && !isset($data[0]['error'])) {
        $stats = [];
        
        // Статистика по суммам
        $sum_fields = ['total_price', 'price', 'amount'];
        foreach ($sum_fields as $field) {
            if (isset($data[0][$field])) {
                $total = 0;
                $count = 0;
                foreach ($data as $row) {
                    if (isset($row[$field]) && is_numeric($row[$field])) {
                        $total += floatval($row[$field]);
                        $count++;
                    }
                }
                if ($count > 0) {
                    $stats['financial'] = [
                        'total_' . $field => $total,
                        'average_' . $field => $total / $count,
                        'records_with_' . $field => $count
                    ];
                }
                break;
            }
        }
        
        // Статистика по статусам
        if (isset($data[0]['status'])) {
            $status_counts = [];
            foreach ($data as $row) {
                if (isset($row['status'])) {
                    $status = $row['status'];
                    if (!isset($status_counts[$status])) {
                        $status_counts[$status] = 0;
                    }
                    $status_counts[$status]++;
                }
            }
            if (!empty($status_counts)) {
                $stats['status_distribution'] = $status_counts;
            }
        }
        
        if (!empty($stats)) {
            $json_data['report']['statistics'] = $stats;
        }
    }
    
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    echo json_encode($json_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

// Скачивание как PDF (HTML) - оставляем как резервный вариант
function downloadAsPdf($data, $report_name, $report_type) {
    $filename = sanitizeFileName($report_name) . '_' . date('Y-m-d_H-i') . '.html';
    
    header('Content-Type: text/html');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    echo '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>' . htmlspecialchars($report_name) . '</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { color: #333; border-bottom: 2px solid #4CAF50; padding-bottom: 10px; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 12px; }
            th { background-color: #4CAF50; color: white; padding: 10px; text-align: left; }
            td { padding: 8px; border: 1px solid #ddd; }
            tr:nth-child(even) { background-color: #f2f2f2; }
            .header { margin-bottom: 30px; }
            .footer { margin-top: 30px; font-size: 11px; color: #666; text-align: center; }
            .info-box { background: #f8f9fa; padding: 15px; border-left: 4px solid #4CAF50; margin: 20px 0; }
            .summary { background: #e9f7ef; padding: 10px; margin: 15px 0; border-radius: 5px; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>' . htmlspecialchars($report_name) . '</h1>
            <div class="info-box">
                <strong>Дата формирования:</strong> ' . date('d.m.Y H:i:s') . '<br>
                <strong>Тип отчета:</strong> ' . htmlspecialchars($report_type) . '
            </div>
        </div>';
    
    if (!empty($data) && !isset($data[0]['error'])) {
        echo '<div class="summary">
                <strong>Всего записей:</strong> ' . count($data) . '
              </div>';
        
        echo '<table>';
        echo '<thead><tr>';
        foreach (array_keys($data[0]) as $header) {
            echo '<th>' . htmlspecialchars($header) . '</th>';
        }
        echo '</tr></thead>';
        
        echo '<tbody>';
        foreach ($data as $row) {
            echo '<tr>';
            foreach ($row as $cell) {
                echo '<td>' . htmlspecialchars($cell) . '</td>';
            }
            echo '</tr>';
        }
        echo '</tbody></table>';
    } else {
        $error_msg = isset($data[0]['error']) ? $data[0]['error'] : 'Нет данных для отчета';
        echo '<div class="info-box" style="border-left-color: #dc3545;">
                <strong>Информация:</strong> ' . htmlspecialchars($error_msg) . '
              </div>';
    }
    
    echo '<div class="footer">
            <p>Отчет сгенерирован системой "Улей"</p>
            <p>Формат: HTML для печати</p>
          </div>
    </body>
    </html>';
}

// Функция для очистки имени файла
function sanitizeFileName($name) {
    $name = preg_replace('/[^\w\s-]/', '', $name);
    $name = preg_replace('/\s+/', '_', $name);
    return $name;
}

// Генерация отчета
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_report'])) {
    $report_type = $_POST['report_type'];
    $period_start = $_POST['period_start'];
    $period_end = $_POST['period_end'];
    $format = $_POST['format'] ?? 'csv';
    
    // Генерируем имя отчета
    $report_types = [
        'sales' => 'Отчет по продажам',
        'bookings' => 'Отчет по бронированиям',
        'users' => 'Отчет по пользователям',
        'tours' => 'Отчет по турам'
    ];
    
    $report_name = ($report_types[$report_type] ?? 'Отчет') . " за период " . 
                   date('d.m.Y', strtotime($period_start)) . " - " . 
                   date('d.m.Y', strtotime($period_end));
    
    // Сохраняем в базу данных
    $parameters = json_encode([
        'type' => $report_type, 
        'start' => $period_start, 
        'end' => $period_end,
        'format' => $format
    ]);
    
    try {
        // Создаем таблицу reports если ее нет
        $pdo->exec("CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            report_type VARCHAR(50) NOT NULL,
            report_name VARCHAR(255) NOT NULL,
            period_start DATE NOT NULL,
            period_end DATE NOT NULL,
            generated_by INTEGER NOT NULL,
            parameters TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
        
        $stmt = $pdo->prepare("INSERT INTO reports (report_type, report_name, period_start, period_end, generated_by, parameters) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$report_type, $report_name, $period_start, $period_end, $_SESSION['user_id'], $parameters]);
        
        $report_id = $pdo->lastInsertId();
        
        // Перенаправляем на скачивание
        header("Location: reports.php?download=" . $report_id);
        exit();
    } catch (PDOException $e) {
        $error = "Ошибка при создании отчета: " . $e->getMessage();
    }
}

// Удаление отчета
if (isset($_GET['delete'])) {
    $report_id = intval($_GET['delete']);
    try {
        $stmt = $pdo->prepare("DELETE FROM reports WHERE id = ?");
        $stmt->execute([$report_id]);
        
        header("Location: reports.php?success=Отчет удален");
        exit();
    } catch (PDOException $e) {
        $error = "Ошибка при удалении: " . $e->getMessage();
    }
}

// Получаем все отчеты
try {
    // Проверяем существование таблицы reports
    $table_exists = $pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name='reports'")->fetch();
    
    if ($table_exists) {
        $reports = $pdo->query("SELECT r.*, u.full_name as generator_name 
                               FROM reports r 
                               LEFT JOIN users u ON r.generated_by = u.id 
                               ORDER BY r.created_at DESC")->fetchAll();
    } else {
        $reports = [];
    }
} catch (PDOException $e) {
    $error = "Ошибка при загрузке отчетов: " . $e->getMessage();
    $reports = [];
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Отчеты - Админ панель - Улей</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .report-actions { display: flex; gap: 5px; }
        .format-badge {
            display: inline-block;
            padding: 2px 8px;
            background: #6c757d;
            color: white;
            border-radius: 3px;
            font-size: 11px;
            margin-left: 5px;
        }
        .alert { padding: 12px; margin: 15px 0; border-radius: 4px; }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-danger { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .form-row { display: flex; gap: 20px; margin-bottom: 15px; }
        .form-group { flex: 1; }
        .btn { padding: 8px 16px; border-radius: 4px; text-decoration: none; display: inline-block; }
        .btn-primary { background: #007bff; color: white; border: 1px solid #007bff; }
        .btn-secondary { background: #6c757d; color: white; border: 1px solid #6c757d; }
        .btn-danger { background: #dc3545; color: white; border: 1px solid #dc3545; }
        .btn-sm { padding: 4px 8px; font-size: 12px; }
        .text-muted { color: #6c757d; }
        .format-description {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        .format-option {
            margin-bottom: 5px;
        }
        .format-icon {
            display: inline-block;
            width: 20px;
            text-align: center;
        }
        @media (max-width: 768px) {
            .form-row { flex-direction: column; gap: 10px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <?php include '../includes/header.php'; ?>
        
        <main>
            <h2>📊 Генератор отчетов</h2>
            
            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success">✅ <?php echo htmlspecialchars($_GET['success']); ?></div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger">❌ <?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <!-- Форма генерации отчета -->
            <div class="card mb-4">
                <h3>➕ Создать новый отчет</h3>
                <form method="POST">
                    <div class="form-row">
                        <div class="form-group">
                            <label>📋 Тип отчета:</label>
                            <select name="report_type" class="form-control" required>
                                <option value="sales">💰 Продажи</option>
                                <option value="bookings">📅 Бронирования</option>
                                <option value="users">👥 Пользователи</option>
                                <option value="tours">🌍 Туры</option>
                            </select>
                            <small class="text-muted">Выберите тип данных для отчета</small>
                        </div>
                        
                        <div class="form-group">
                            <label>📁 Формат файла:</label>
                            <select name="format" class="form-control" required id="formatSelect">
                                <option value="csv">📊 CSV (для Excel/Google Sheets)</option>
                                <option value="excel">📈 Excel (HTML таблица)</option>
                                <option value="json">🔤 JSON (структурированные данные)</option>
                                <option value="pdf">📄 HTML (для печати)</option>
                            </select>
                            <div id="formatDescription" class="format-description">
                                <div class="format-option" data-format="csv">
                                    <span class="format-icon">📊</span> <strong>CSV</strong> - Лучший формат для импорта в Excel, Google Sheets, 1C
                                </div>
                                <div class="format-option" data-format="excel" style="display: none;">
                                    <span class="format-icon">📈</span> <strong>Excel</strong> - Готовая HTML таблица для открытия в Excel
                                </div>
                                <div class="format-option" data-format="json" style="display: none;">
                                    <span class="format-icon">🔤</span> <strong>JSON</strong> - Структурированные данные для программной обработки
                                </div>
                                <div class="format-option" data-format="pdf" style="display: none;">
                                    <span class="format-icon">📄</span> <strong>HTML</strong> - Отформатированный отчет для печати или просмотра
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>📅 Период с:</label>
                            <input type="date" name="period_start" class="form-control" required 
                                   value="<?php echo date('Y-m-01'); ?>" id="periodStart">
                        </div>
                        
                        <div class="form-group">
                            <label>📅 по:</label>
                            <input type="date" name="period_end" class="form-control" required 
                                   value="<?php echo date('Y-m-d'); ?>" id="periodEnd">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" name="generate_report" class="btn btn-primary" id="generateBtn">
                            <span id="btnIcon">🚀</span> <span id="btnText">Создать и скачать отчет</span>
                        </button>
                        <small class="text-muted d-block mt-1" id="fileHint">Будет создан файл в формате CSV</small>
                    </div>
                </form>
            </div>
            
            <!-- Список отчетов -->
            <div class="card">
                <h3>📜 История отчетов</h3>
                
                <?php if (empty($reports)): ?>
                    <div class="text-center py-4">
                        <p>📭 Отчетов пока нет</p>
                        <p class="text-muted">Создайте свой первый отчет</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Название</th>
                                    <th>Тип</th>
                                    <th>Период</th>
                                    <th>Дата</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($reports as $report): 
                                    $params = json_decode($report['parameters'], true);
                                    $format = $params['format'] ?? 'csv';
                                    
                                    // Иконки и цвета для типов
                                    $type_info = [
                                        'sales' => ['icon' => '💰', 'color' => '#28a745', 'text' => 'Продажи'],
                                        'bookings' => ['icon' => '📅', 'color' => '#17a2b8', 'text' => 'Бронирования'],
                                        'users' => ['icon' => '👥', 'color' => '#ffc107', 'text' => 'Пользователи'],
                                        'tours' => ['icon' => '🌍', 'color' => '#dc3545', 'text' => 'Туры']
                                    ];
                                    $info = $type_info[$report['report_type']] ?? ['icon' => '📄', 'color' => '#6c757d', 'text' => $report['report_type']];
                                    
                                    // Иконки для форматов
                                    $format_info = [
                                        'csv' => ['icon' => '📊', 'text' => 'CSV'],
                                        'excel' => ['icon' => '📈', 'text' => 'Excel'],
                                        'json' => ['icon' => '🔤', 'text' => 'JSON'],
                                        'pdf' => ['icon' => '📄', 'text' => 'HTML']
                                    ];
                                    $format_data = $format_info[$format] ?? ['icon' => '📁', 'text' => strtoupper($format)];
                                ?>
                                <tr>
                                    <td><?php echo $report['id']; ?></td>
                                    <td>
                                        <span style="color: <?php echo $info['color']; ?>" title="<?php echo $info['text']; ?>">
                                            <?php echo $info['icon']; ?>
                                        </span>
                                        <?php echo htmlspecialchars($report['report_name']); ?>
                                        <span class="format-badge" style="background-color: <?php echo $info['color']; ?>" title="Формат: <?php echo $format_data['text']; ?>">
                                            <?php echo $format_data['icon']; ?> <?php echo $format_data['text']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo $info['text']; ?></td>
                                    <td>
                                        <small>
                                            <?php echo date('d.m.Y', strtotime($report['period_start'])); ?><br>
                                            <?php echo date('d.m.Y', strtotime($report['period_end'])); ?>
                                        </small>
                                    </td>
                                    <td>
                                        <small><?php echo date('d.m.Y', strtotime($report['created_at'])); ?></small><br>
                                        <small class="text-muted"><?php echo date('H:i', strtotime($report['created_at'])); ?></small>
                                    </td>
                                    <td>
                                        <div class="report-actions">
                                            <a href="?download=<?php echo $report['id']; ?>" 
                                               class="btn btn-sm btn-secondary"
                                               title="Скачать отчет в формате <?php echo $format_data['text']; ?>">
                                                <?php echo $format_data['icon']; ?> Скачать
                                            </a>
                                            <a href="?delete=<?php echo $report['id']; ?>" 
                                               class="btn btn-sm btn-danger"
                                               onclick="return confirm('Удалить этот отчет?')"
                                               title="Удалить отчет">
                                                🗑️
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Информация о доступных таблицах -->
            <div class="card mt-4">
                <h3>ℹ️ Информация о базе данных</h3>
                <div class="row">
                    <?php
                    $tables = ['bookings', 'users', 'tours'];
                    foreach ($tables as $table): 
                        $columns = getTableColumns($table);
                    ?>
                    <div class="col-md-4 mb-3">
                        <div class="card h-100">
                            <div class="card-body">
                                <h5>
                                    <?php 
                                    $table_icons = [
                                        'bookings' => '📅',
                                        'users' => '👥',
                                        'tours' => '🌍'
                                    ];
                                    echo ($table_icons[$table] ?? '📋') . ' ' . ucfirst($table); 
                                    ?>
                                </h5>
                                <?php if (!empty($columns)): ?>
                                    <p class="text-success">✓ Таблица найдена</p>
                                    <p><small class="text-muted">Колонок: <?php echo count($columns); ?></small></p>
                                    <div style="max-height: 100px; overflow-y: auto; font-size: 11px; background: #f8f9fa; padding: 8px; border-radius: 4px;">
                                        <?php 
                                        foreach ($columns as $index => $column) {
                                            echo '<span style="display: inline-block; margin: 2px; padding: 2px 6px; background: #e9ecef; border-radius: 3px;">' . htmlspecialchars($column) . '</span>';
                                            if (($index + 1) % 3 == 0) echo '<br>';
                                        }
                                        ?>
                                    </div>
                                <?php else: ?>
                                    <p class="text-danger">✗ Таблица не найдена</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- Описание форматов -->
            <div class="card mt-4">
                <h3>📋 Описание форматов</h3>
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <div class="card h-100">
                            <div class="card-body">
                                <h5>📊 CSV</h5>
                                <p><small>Формат с разделителями</small></p>
                                <ul class="small">
                                    <li>Лучше всего для Excel</li>
                                    <li>Импорт в 1С и Google Sheets</li>
                                    <li>Малый размер файла</li>
                                    <li>Простая обработка</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="card h-100">
                            <div class="card-body">
                                <h5>📈 Excel</h5>
                                <p><small>HTML таблица</small></p>
                                <ul class="small">
                                    <li>Готовое форматирование</li>
                                    <li>Цветные заголовки</li>
                                    <li>Открывается в Excel</li>
                                    <li>Чередование строк</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="card h-100">
                            <div class="card-body">
                                <h5>🔤 JSON</h5>
                                <p><small>Структурированные данные</small></p>
                                <ul class="small">
                                    <li>Полная структура данных</li>
                                    <li>Метаданные и статистика</li>
                                    <li>Идеально для API</li>
                                    <li>Машинная обработка</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="card h-100">
                            <div class="card-body">
                                <h5>📄 HTML</h5>
                                <p><small>Версия для печати</small></p>
                                <ul class="small">
                                    <li>Красивое форматирование</li>
                                    <li>Готово к печати</li>
                                    <li>Статистика в отчете</li>
                                    <li>Легко читать</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        
        <?php include '../includes/footer.php'; ?>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const formatSelect = document.getElementById('formatSelect');
            const formatDescription = document.getElementById('formatDescription');
            const formatOptions = formatDescription.querySelectorAll('.format-option');
            const fileHint = document.getElementById('fileHint');
            const btnIcon = document.getElementById('btnIcon');
            const btnText = document.getElementById('btnText');
            const periodStart = document.getElementById('periodStart');
            const periodEnd = document.getElementById('periodEnd');
            const generateBtn = document.getElementById('generateBtn');
            
            // Функция обновления описания формата
            function updateFormatDescription() {
                const selectedFormat = formatSelect.value;
                
                // Скрываем все описания
                formatOptions.forEach(option => {
                    option.style.display = 'none';
                });
                
                // Показываем выбранное
                const selectedOption = formatDescription.querySelector(`[data-format="${selectedFormat}"]`);
                if (selectedOption) {
                    selectedOption.style.display = 'block';
                }
                
                // Обновляем подсказку и кнопку
                const formatInfo = {
                    'csv': {hint: 'Будет создан CSV файл (лучше всего для Excel)', icon: '📊', text: 'Создать CSV'},
                    'excel': {hint: 'Будет создан Excel файл (HTML таблица)', icon: '📈', text: 'Создать Excel'},
                    'json': {hint: 'Будет создан JSON файл со структурой данных', icon: '🔤', text: 'Создать JSON'},
                    'pdf': {hint: 'Будет создан HTML файл для печати', icon: '📄', text: 'Создать HTML'}
                };
                
                if (formatInfo[selectedFormat]) {
                    fileHint.textContent = formatInfo[selectedFormat].hint;
                    btnIcon.textContent = formatInfo[selectedFormat].icon;
                    btnText.textContent = formatInfo[selectedFormat].text;
                }
            }
            
            // Инициализация
            updateFormatDescription();
            
            // Обработчик изменения формата
            formatSelect.addEventListener('change', updateFormatDescription);
            
            // Устанавливаем период по умолчанию
            if (periodStart && periodEnd) {
                const now = new Date();
                const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
                
                if (!periodStart.value) {
                    periodStart.value = firstDay.toISOString().split('T')[0];
                }
                
                if (!periodEnd.value) {
                    periodEnd.value = now.toISOString().split('T')[0];
                }
            }
            
            // Валидация формы
            if (generateBtn) {
                generateBtn.addEventListener('click', function(e) {
                    if (!periodStart.value || !periodEnd.value) {
                        e.preventDefault();
                        alert('❌ Пожалуйста, заполните даты начала и окончания периода!');
                        return;
                    }
                    
                    const start = new Date(periodStart.value);
                    const end = new Date(periodEnd.value);
                    
                    if (start > end) {
                        e.preventDefault();
                        alert('❌ Дата начала не может быть позже даты окончания!');
                        return;
                    }
                    
                    // Проверяем что период не слишком большой
                    const diffTime = Math.abs(end - start);
                    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                    
                    if (diffDays > 365) {
                        if (!confirm(`Выбран период ${diffDays} дней (более 1 года). Это может занять много времени. Продолжить?`)) {
                            e.preventDefault();
                            return;
                        }
                    }
                    
                    // Показываем уведомление о начале генерации
                    const selectedFormat = formatSelect.value;
                    const formatNames = {
                        'csv': 'CSV',
                        'excel': 'Excel',
                        'json': 'JSON',
                        'pdf': 'HTML'
                    };
                    
                    generateBtn.disabled = true;
                    generateBtn.innerHTML = '⏳ Генерация...';
                    
                    setTimeout(() => {
                        generateBtn.disabled = false;
                        generateBtn.innerHTML = `${btnIcon.textContent} ${btnText.textContent}`;
                    }, 3000);
                });
            }
            
            // Быстрый выбор периода
            const quickPeriods = document.createElement('div');
            quickPeriods.className = 'mb-3';
            quickPeriods.innerHTML = `
                <small class="d-block mb-2">📅 Быстрый выбор периода:</small>
                <div class="btn-group btn-group-sm">
                    <button type="button" class="btn btn-outline-secondary" data-days="7">Неделя</button>
                    <button type="button" class="btn btn-outline-secondary" data-days="30">Месяц</button>
                    <button type="button" class="btn btn-outline-secondary" data-days="90">Квартал</button>
                    <button type="button" class="btn btn-outline-secondary" data-days="365">Год</button>
                </div>
            `;
            
            periodStart.parentNode.parentNode.appendChild(quickPeriods);
            
            // Обработчики быстрого выбора
            quickPeriods.querySelectorAll('button').forEach(button => {
                button.addEventListener('click', function() {
                    const days = parseInt(this.getAttribute('data-days'));
                    const end = new Date();
                    const start = new Date();
                    start.setDate(start.getDate() - days + 1);
                    
                    periodStart.value = start.toISOString().split('T')[0];
                    periodEnd.value = end.toISOString().split('T')[0];
                });
            });
        });
    </script>
</body>
</html>