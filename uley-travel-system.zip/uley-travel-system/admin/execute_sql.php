<?php
session_start();
require_once '../config.php';
require_once '../includes/auth.php';

if (!isAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Список запрещенных команд
$forbidden_commands = [
    'DROP DATABASE',
    'DROP TABLE',
    'TRUNCATE',
    'DELETE FROM',
    'ALTER TABLE',
    'CREATE TABLE',
    'CREATE DATABASE',
    'GRANT',
    'REVOKE',
    'FLUSH',
    'RESET',
    'SHUTDOWN',
    'KILL'
];

// Функция для проверки запроса
function isSafeQuery($query) {
    global $forbidden_commands;
    
    $query_upper = strtoupper(trim($query));
    
    // Проверяем на запрещенные команды
    foreach ($forbidden_commands as $cmd) {
        if (strpos($query_upper, $cmd) === 0) {
            return false;
        }
    }
    
    // Разрешаем только SELECT, UPDATE с WHERE, INSERT, ограниченный DELETE
    if (strpos($query_upper, 'SELECT') === 0 || 
        strpos($query_upper, 'INSERT') === 0 ||
        (strpos($query_upper, 'UPDATE') === 0 && strpos($query_upper, 'WHERE') !== false) ||
        (strpos($query_upper, 'DELETE') === 0 && strpos($query_upper, 'WHERE') !== false)) {
        return true;
    }
    
    return false;
}

$error = '';
$result = null;
$execution_time = 0;
$row_count = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sql_query'])) {
    $sql_query = trim($_POST['sql_query']);
    
    if (empty($sql_query)) {
        $error = "SQL запрос не может быть пустым";
    } elseif (!isSafeQuery($sql_query)) {
        $error = "Запрос содержит запрещенные команды или небезопасен. Разрешены только SELECT, INSERT, UPDATE с WHERE и DELETE с WHERE.";
    } else {
        try {
            $start_time = microtime(true);
            
            // Для SELECT запросов используем подготовленные выражения если есть параметры
            if (strtoupper(substr($sql_query, 0, 6)) === 'SELECT') {
                $stmt = $pdo->query($sql_query);
                $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $row_count = count($result);
            } else {
                // Для других запросов
                $stmt = $pdo->exec($sql_query);
                $row_count = $stmt;
                $result = ['affected_rows' => $row_count, 'message' => 'Запрос выполнен успешно'];
            }
            
            $end_time = microtime(true);
            $execution_time = round(($end_time - $start_time) * 1000, 2); // В миллисекундах
            
            // Логируем запрос
            logAction($pdo, $_SESSION['user_id'], 'execute_sql', substr($sql_query, 0, 200));
            
        } catch (PDOException $e) {
            $error = "Ошибка SQL: " . $e->getMessage();
            $error .= "\nЗапрос: " . htmlspecialchars($sql_query);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Выполнение SQL - Улей</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .sql-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-top: 20px;
        }
        .sql-form {
            grid-column: 1;
        }
        .sql-result {
            grid-column: 2;
        }
        .sql-editor {
            width: 100%;
            height: 200px;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            padding: 10px;
            border: 1px solid var(--primary-yellow);
            border-radius: 5px;
            background-color: #1a1a1a;
            color: #fff;
            resize: vertical;
        }
        .query-examples {
            margin-top: 20px;
            background: var(--dark-gray);
            padding: 15px;
            border-radius: 5px;
        }
        .example-query {
            background: #333;
            padding: 10px;
            margin: 10px 0;
            border-left: 3px solid var(--primary-yellow);
            font-family: monospace;
            cursor: pointer;
            transition: background 0.3s;
        }
        .example-query:hover {
            background: #444;
        }
        .result-table {
            max-height: 400px;
            overflow-y: auto;
        }
        .stats {
            display: flex;
            gap: 20px;
            margin: 10px 0;
            padding: 10px;
            background: var(--dark-gray);
            border-radius: 5px;
        }
        .stat-item {
            display: flex;
            flex-direction: column;
        }
        .stat-value {
            font-weight: bold;
            color: var(--primary-yellow);
        }
    </style>
</head>
<body>
    <div class="container">
        <?php include '../includes/header.php'; ?>
        
        <main>
            <h2>Выполнение SQL запросов</h2>
            
            <div class="alert alert-info">
                <strong>Внимание!</strong> SQL запросы выполняются напрямую в базе данных. Будьте осторожны!
                Разрешены только SELECT, INSERT, UPDATE с WHERE и DELETE с WHERE.
            </div>
            
            <div class="sql-container">
                <!-- Форма для ввода SQL -->
                <div class="sql-form">
                    <form method="POST" action="">
                        <div class="form-group">
                            <label>SQL запрос:</label>
                            <textarea name="sql_query" class="sql-editor" 
                                      placeholder="Введите SQL запрос..."><?php echo isset($_POST['sql_query']) ? htmlspecialchars($_POST['sql_query']) : ''; ?></textarea>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Выполнить запрос</button>
                            <button type="button" class="btn btn-secondary" onclick="clearQuery()">Очистить</button>
                        </div>
                    </form>
                    
                    <!-- Примеры запросов -->
                    <div class="query-examples">
                        <h4>Примеры запросов:</h4>
                        
                        <div class="example-query" onclick="insertQuery('SELECT * FROM users LIMIT 10')">
                            SELECT * FROM users LIMIT 10
                        </div>
                        
                        <div class="example-query" onclick="insertQuery('SELECT * FROM tours WHERE is_available = 1')">
                            SELECT * FROM tours WHERE is_available = 1
                        </div>
                        
                        <div class="example-query" onclick="insertQuery('SELECT u.full_name, COUNT(b.id) as bookings_count FROM users u LEFT JOIN bookings b ON u.id = b.user_id GROUP BY u.id')">
                            SELECT u.full_name, COUNT(b.id) as bookings_count FROM users u LEFT JOIN bookings b ON u.id = b.user_id GROUP BY u.id
                        </div>
                        
                        <div class="example-query" onclick="insertQuery('SELECT country, COUNT(*) as tours_count FROM tours GROUP BY country ORDER BY tours_count DESC')">
                            SELECT country, COUNT(*) as tours_count FROM tours GROUP BY country ORDER BY tours_count DESC
                        </div>
                    </div>
                </div>
                
                <!-- Результаты выполнения -->
                <div class="sql-result">
                    <?php if ($error): ?>
                        <div class="alert alert-error">
                            <strong>Ошибка:</strong><br>
                            <pre><?php echo htmlspecialchars($error); ?></pre>
                        </div>
                    <?php elseif ($result !== null): ?>
                        <div class="stats">
                            <div class="stat-item">
                                <span>Время выполнения:</span>
                                <span class="stat-value"><?php echo $execution_time; ?> мс</span>
                            </div>
                            <div class="stat-item">
                                <span>Затронуто строк:</span>
                                <span class="stat-value"><?php echo $row_count; ?></span>
                            </div>
                        </div>
                        
                        <?php if (is_array($result) && count($result) > 0): ?>
                            <div class="result-table">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <?php foreach (array_keys($result[0]) as $column): ?>
                                                <th><?php echo htmlspecialchars($column); ?></th>
                                            <?php endforeach; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($result as $row): ?>
                                            <tr>
                                                <?php foreach ($row as $cell): ?>
                                                    <td>
                                                        <?php 
                                                        if ($cell === null) {
                                                            echo '<em>NULL</em>';
                                                        } elseif (is_string($cell) && strlen($cell) > 100) {
                                                            echo htmlspecialchars(substr($cell, 0, 100)) . '...';
                                                        } else {
                                                            echo htmlspecialchars($cell);
                                                        }
                                                        ?>
                                                    </td>
                                                <?php endforeach; ?>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Кнопка экспорта -->
                            <div class="mt-3">
                                <button onclick="exportToJSON()" class="btn btn-success">Экспорт в JSON</button>
                                <button onclick="copyToClipboard()" class="btn btn-secondary">Копировать результат</button>
                            </div>
                            
                            <!-- Скрытый элемент для экспорта -->
                            <div id="jsonData" style="display: none;">
                                <?php echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE); ?>
                            </div>
                            
                        <?php elseif (is_array($result) && count($result) === 0): ?>
                            <div class="alert alert-info">
                                Запрос выполнен успешно, но не вернул данных.
                            </div>
                        <?php else: ?>
                            <div class="alert alert-success">
                                <strong>Запрос выполнен успешно!</strong><br>
                                <?php 
                                if (is_array($result)) {
                                    foreach ($result as $key => $value) {
                                        echo htmlspecialchars($key) . ": " . htmlspecialchars($value) . "<br>";
                                    }
                                } else {
                                    echo "Результат: " . htmlspecialchars($result);
                                }
                                ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
    
    <script>
        function insertQuery(query) {
            document.querySelector('textarea[name="sql_query"]').value = query;
        }
        
        function clearQuery() {
            document.querySelector('textarea[name="sql_query"]').value = '';
        }
        
        function exportToJSON() {
            const data = document.getElementById('jsonData').textContent;
            const blob = new Blob([data], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'sql_result_' + new Date().toISOString().slice(0,10) + '.json';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }
        
        function copyToClipboard() {
            const data = document.getElementById('jsonData').textContent;
            navigator.clipboard.writeText(data)
                .then(() => {
                    alert('Результат скопирован в буфер обмена');
                })
                .catch(err => {
                    console.error('Ошибка копирования: ', err);
                });
        }
        
        // Автоматический подсчет строк в текстовом поле
        const textarea = document.querySelector('.sql-editor');
        if (textarea) {
            textarea.addEventListener('input', function() {
                const lines = this.value.split('\n').length;
                const chars = this.value.length;
                // Можно добавить отображение статистики
            });
        }
    </script>
</body>
</html>