<?php
session_start();
require_once '../config.php';
require_once '../includes/auth.php';

if (!isAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Добавление пользователя
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $full_name = $_POST['full_name'];
    $phone = $_POST['phone'];
    
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("INSERT INTO users (email, password_hash, role, full_name, phone) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$email, $password_hash, $role, $full_name, $phone]);
    $success = "Пользователь успешно добавлен";
}

// Редактирование пользователя
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_user'])) {
    $id = $_POST['id'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $full_name = $_POST['full_name'];
    $phone = $_POST['phone'];
    
    $stmt = $pdo->prepare("UPDATE users SET email = ?, role = ?, full_name = ?, phone = ? WHERE id = ?");
    $stmt->execute([$email, $role, $full_name, $phone, $id]);
    $success = "Пользователь успешно обновлен";
}

// Удаление пользователя
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $success = "Пользователь успешно удален";
}

// Получение всех пользователей
$users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление пользователями - Админ панель - Улей</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <?php include '../includes/header.php'; ?>
        
        <main>
            <h2>Управление пользователями</h2>
            
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <!-- Форма добавления/редактирования -->
            <div class="card mb-4">
                <h3><?php echo isset($_GET['edit']) ? 'Редактировать пользователя' : 'Добавить нового пользователя'; ?></h3>
                <form method="POST">
                    <?php
                    $edit_user = null;
                    if (isset($_GET['edit'])) {
                        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
                        $stmt->execute([$_GET['edit']]);
                        $edit_user = $stmt->fetch();
                    }
                    ?>
                    
                    <input type="hidden" name="id" value="<?php echo $edit_user['id'] ?? ''; ?>">
                    
                    <div class="form-group">
                        <label>Email:</label>
                        <input type="email" name="email" class="form-control" 
                               value="<?php echo htmlspecialchars($edit_user['email'] ?? ''); ?>" required>
                    </div>
                    
                    <?php if (!isset($_GET['edit'])): ?>
                    <div class="form-group">
                        <label>Пароль:</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label>Роль:</label>
                        <select name="role" class="form-control" required>
                            <option value="client" <?php echo ($edit_user['role'] ?? '') == 'client' ? 'selected' : ''; ?>>Клиент</option>
                            <option value="manager" <?php echo ($edit_user['role'] ?? '') == 'manager' ? 'selected' : ''; ?>>Менеджер</option>
                            <option value="admin" <?php echo ($edit_user['role'] ?? '') == 'admin' ? 'selected' : ''; ?>>Админ</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>ФИО:</label>
                        <input type="text" name="full_name" class="form-control" 
                               value="<?php echo htmlspecialchars($edit_user['full_name'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Телефон:</label>
                        <input type="tel" name="phone" class="form-control" 
                               value="<?php echo htmlspecialchars($edit_user['phone'] ?? ''); ?>">
                    </div>
                    
                    <button type="submit" name="<?php echo isset($_GET['edit']) ? 'edit_user' : 'add_user'; ?>" 
                            class="btn btn-primary">
                        <?php echo isset($_GET['edit']) ? 'Сохранить изменения' : 'Добавить пользователя'; ?>
                    </button>
                    
                    <?php if (isset($_GET['edit'])): ?>
                        <a href="users.php" class="btn btn-secondary">Отмена</a>
                    <?php endif; ?>
                </form>
            </div>
            
            <!-- Список пользователей -->
            <div class="card">
                <h3>Список пользователей</h3>
                
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Email</th>
                            <th>Роль</th>
                            <th>ФИО</th>
                            <th>Телефон</th>
                            <th>Дата регистрации</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo $user['id']; ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo $user['role']; ?></td>
                            <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($user['phone']); ?></td>
                            <td><?php echo date('d.m.Y H:i', strtotime($user['created_at'])); ?></td>
                            <td>
                                <a href="?edit=<?php echo $user['id']; ?>" class="btn btn-sm btn-secondary">Редактировать</a>
                                <a href="?delete=<?php echo $user['id']; ?>" 
                                   class="btn btn-sm btn-danger" 
                                   onclick="return confirm('Удалить этого пользователя?')">Удалить</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
        
        <?php include '../includes/footer.php'; ?>
    </div>
</body>
</html>