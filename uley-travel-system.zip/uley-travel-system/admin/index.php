<?php
session_start();
require_once '../config.php';
require_once '../includes/auth.php';

if (!isAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Статистика для админа
$total_users = $pdo->query("SELECT COUNT(*) as count FROM users")->fetch()['count'];
$total_tours = $pdo->query("SELECT COUNT(*) as count FROM tours")->fetch()['count'];
$total_bookings = $pdo->query("SELECT COUNT(*) as count FROM bookings")->fetch()['count'];

// Исправление: проверка на NULL перед number_format
$revenue_result = $pdo->query("SELECT SUM(total_price) as total FROM bookings WHERE status = 'completed'")->fetch();
$total_revenue = $revenue_result['total'] ? $revenue_result['total'] : 0;
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ панель - Улей</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container">
        <?php include '../includes/header.php'; ?>
        
        <main>
            <h2>Административная панель</h2>
            
            <div class="admin-grid">
                <div class="admin-card">
                    <h3>Быстрый доступ</h3>
                    <div class="admin-actions">
                        <a href="users.php" class="btn btn-primary btn-block">Управление пользователями</a>
                        <a href="tours.php" class="btn btn-primary btn-block">Управление турами</a>
                        <a href="bookings.php" class="btn btn-primary btn-block">Все бронирования</a>
                        <a href="reports.php" class="btn btn-primary btn-block">Отчеты</a>
                        <a href="../backup.php" class="btn btn-success btn-block">Бэкапирование</a>
                    </div>
                </div>
                
                <div class="admin-card">
                    <h3>Статистика системы</h3>
                    <div class="stats">
                        <div class="stat-item">
                            <span class="stat-label">Пользователей:</span>
                            <span class="stat-value"><?php echo $total_users; ?></span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Туров:</span>
                            <span class="stat-value"><?php echo $total_tours; ?></span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Бронирований:</span>
                            <span class="stat-value"><?php echo $total_bookings; ?></span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Выручка:</span>
                            <span class="stat-value"><?php echo number_format($total_revenue, 0, ',', ' '); ?> ₽</span>
                        </div>
                    </div>
                </div>
                
                <div class="admin-card chart-container">
                    <h3>График активности</h3>
                    <canvas id="activityChart"></canvas>
                </div>
                
                <div class="admin-card">
                    <h3>SQL Запросы</h3>
                    <form method="POST" action="execute_sql.php" target="_blank">
                        <textarea name="sql_query" class="form-control" rows="4" 
                                  placeholder="SELECT * FROM users LIMIT 10"></textarea>
                        <button type="submit" class="btn btn-warning btn-block mt-2">Выполнить запрос</button>
                    </form>
                </div>
            </div>
        </main>
        
        <?php include '../includes/footer.php'; ?>
    </div>
    
    <script>
        // График активности
        const ctx = document.getElementById('activityChart').getContext('2d');
        const activityChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'],
                datasets: [{
                    label: 'Бронирования',
                    data: [12, 19, 15, 25, 22, 30, 18],
                    backgroundColor: 'rgba(255, 215, 0, 0.2)',
                    borderColor: 'rgba(255, 215, 0, 1)',
                    borderWidth: 2,
                    fill: true
                }, {
                    label: 'Регистрации',
                    data: [5, 8, 7, 10, 9, 12, 6],
                    backgroundColor: 'rgba(0, 123, 255, 0.2)',
                    borderColor: 'rgba(0, 123, 255, 1)',
                    borderWidth: 2,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>