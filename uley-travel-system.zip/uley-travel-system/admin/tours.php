<?php
session_start();
require_once '../config.php';
require_once '../includes/auth.php';

if (!isAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Добавление тура
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_tour'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $country = $_POST['country'];
    $city = $_POST['city'];
    $price = $_POST['price'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $is_available = isset($_POST['is_available']) ? 1 : 0;
    
    $stmt = $pdo->prepare("INSERT INTO tours (title, description, country, city, price, start_date, end_date, is_available, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$title, $description, $country, $city, $price, $start_date, $end_date, $is_available, $_SESSION['user_id']]);
    $success = "Тур успешно добавлен";
}

// Редактирование тура
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_tour'])) {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $country = $_POST['country'];
    $city = $_POST['city'];
    $price = $_POST['price'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $is_available = isset($_POST['is_available']) ? 1 : 0;
    
    $stmt = $pdo->prepare("UPDATE tours SET title = ?, description = ?, country = ?, city = ?, price = ?, start_date = ?, end_date = ?, is_available = ? WHERE id = ?");
    $stmt->execute([$title, $description, $country, $city, $price, $start_date, $end_date, $is_available, $id]);
    $success = "Тур успешно обновлен";
}

if (isset($_GET['delete'])) {
    // Валидируем ID
    $id = filter_var($_GET['delete'], FILTER_VALIDATE_INT);
    
    if ($id !== false && $id > 0) {
        // Проверяем, существует ли тур
        $checkStmt = $pdo->prepare("SELECT id FROM tours WHERE id = ?");
        $checkStmt->execute([$id]);
        
        if ($checkStmt->fetch()) {
            // Логируем действие
            logAction($pdo, $_SESSION['user_id'], 'DELETE_TOUR', "Удален тур #{$id}");
            
            // Удаляем тур
            $stmt = $pdo->prepare("DELETE FROM tours WHERE id = ?");
            if ($stmt->execute([$id])) {
                $success = "Тур успешно удален";
            } else {
                $error = "Ошибка при удалении тура";
            }
        } else {
            $error = "Тур не найден";
        }
    } else {
        $error = "Неверный идентификатор тура";
    }
}


// Экспорт в JSON
if (isset($_GET['export'])) {
    $stmt = $pdo->query("SELECT * FROM tours");
    $tours = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="tours_export.json"');
    echo json_encode($tours, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit();
}

// Получение всех туров
$tours = $pdo->query("SELECT * FROM tours ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление турами - Улей</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <?php include '../includes/header.php'; ?>
        
        <main>
            <h2>Управление турами</h2>
            
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <!-- Форма добавления/редактирования -->
            <div class="card mb-4">
                <h3><?php echo isset($_GET['edit']) ? 'Редактировать тур' : 'Добавить новый тур'; ?></h3>
                <form method="POST">
                    <?php
                    $edit_tour = null;
                    if (isset($_GET['edit'])) {
                        $stmt = $pdo->prepare("SELECT * FROM tours WHERE id = ?");
                        $stmt->execute([$_GET['edit']]);
                        $edit_tour = $stmt->fetch();
                    }
                    ?>
                    
                    <input type="hidden" name="id" value="<?php echo $edit_tour['id'] ?? ''; ?>">
                    
                    <div class="form-group">
                        <label>Название:</label>
                        <input type="text" name="title" class="form-control" 
                               value="<?php echo htmlspecialchars($edit_tour['title'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Описание:</label>
                        <textarea name="description" class="form-control" rows="3"><?php echo htmlspecialchars($edit_tour['description'] ?? ''); ?></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label>Страна:</label>
                                <input type="text" name="country" class="form-control" 
                                       value="<?php echo htmlspecialchars($edit_tour['country'] ?? ''); ?>" required>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label>Город:</label>
                                <input type="text" name="city" class="form-control" 
                                       value="<?php echo htmlspecialchars($edit_tour['city'] ?? ''); ?>" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label>Цена:</label>
                                <input type="number" name="price" class="form-control" step="0.01" 
                                       value="<?php echo $edit_tour['price'] ?? ''; ?>" required>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label>Доступен:</label>
                                <input type="checkbox" name="is_available" value="1" 
                                       <?php echo ($edit_tour['is_available'] ?? 1) ? 'checked' : ''; ?>>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label>Дата начала:</label>
                                <input type="date" name="start_date" class="form-control" 
                                       value="<?php echo $edit_tour['start_date'] ?? ''; ?>">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label>Дата окончания:</label>
                                <input type="date" name="end_date" class="form-control" 
                                       value="<?php echo $edit_tour['end_date'] ?? ''; ?>">
                            </div>
                        </div>
                    </div>
                    
                    <button type="submit" name="<?php echo isset($_GET['edit']) ? 'edit_tour' : 'add_tour'; ?>" 
                            class="btn btn-primary">
                        <?php echo isset($_GET['edit']) ? 'Сохранить изменения' : 'Добавить тур'; ?>
                    </button>
                    
                    <?php if (isset($_GET['edit'])): ?>
                        <a href="tours.php" class="btn btn-secondary">Отмена</a>
                    <?php endif; ?>
                </form>
            </div>
            
            <!-- Список туров -->
            <div class="card">
                <h3>Список туров</h3>
                <a href="?export=json" class="btn btn-success mb-3">Экспорт в JSON</a>
                
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Название</th>
                            <th>Страна</th>
                            <th>Город</th>
                            <th>Цена</th>
                            <th>Доступен</th>
                            <th>Дата создания</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tours as $tour): ?>
                        <tr>
                            <td><?php echo $tour['id']; ?></td>
                            <td><?php echo htmlspecialchars($tour['title']); ?></td>
                            <td><?php echo htmlspecialchars($tour['country']); ?></td>
                            <td><?php echo htmlspecialchars($tour['city']); ?></td>
                            <td><?php echo number_format($tour['price'], 0, ',', ' '); ?> ₽</td>
                            <td><?php echo $tour['is_available'] ? 'Да' : 'Нет'; ?></td>
                            <td><?php echo date('d.m.Y H:i', strtotime($tour['created_at'])); ?></td>
                            <td>
                                <a href="?edit=<?php echo $tour['id']; ?>" class="btn btn-sm btn-secondary">Редактировать</a>
                                <a href="?delete=<?php echo $tour['id']; ?>" 
                                   class="btn btn-sm btn-danger" 
                                   onclick="return confirm('Удалить этот тур?')">Удалить</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>