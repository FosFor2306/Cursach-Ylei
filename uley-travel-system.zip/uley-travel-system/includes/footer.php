        <footer class="footer">
            <p>&copy; <?php echo date('Y'); ?> Улей - Туристическая фирма</p>
            <p>Телефон: +7 (XXX) XXX-XX-XX | Email: info@uley-travel.ru</p>
        </footer>
    </div>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html>