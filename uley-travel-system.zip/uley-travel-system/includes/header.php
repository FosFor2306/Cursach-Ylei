<?php
if (!isset($page_title)) {
    $page_title = 'Улей - Туристическая фирма';
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
</head>
<body>
    <div class="container">
        <header class="header">
            <div class="logo">
                <img src="../assets/images/logo.png" alt="Улей" height="50">
                <h1>Улей</h1>
                <span class="tagline">Туристическая фирма</span>
            </div>
            <nav class="main-nav">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <span class="welcome">Добро пожаловать, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</span>
                    <?php if ($_SESSION['user_role'] == 'admin'): ?>
                        <a href="../admin/" class="btn btn-primary">Админ панель</a>
                    <?php elseif ($_SESSION['user_role'] == 'manager'): ?>
                        <a href="../manager/" class="btn btn-primary">Панель менеджера</a>
                    <?php else: ?>
                        <a href="../client/" class="btn btn-primary">Личный кабинет</a>
                    <?php endif; ?>
                    <a href="../dashboard.php" class="btn btn-secondary">Дашборд</a>
                    <a href="../logout.php" class="btn btn-danger">Выход</a>
                <?php else: ?>
                    <a href="../login.php" class="btn btn-login">Вход</a>
                    <a href="../register.php" class="btn btn-register">Регистрация</a>
                <?php endif; ?>
            </nav>
        </header>