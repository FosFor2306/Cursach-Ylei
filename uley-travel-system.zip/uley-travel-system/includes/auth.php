<?php
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin';
}

function isManager() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'manager';
}

function isClient() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'client';
}

function checkAccess($required_role) {
    if (!isLoggedIn()) {
        header("Location: ../login.php");
        exit();
    }
    
    if ($_SESSION['user_role'] != $required_role && !isAdmin()) {
        die("Доступ запрещен");
    }
}

function getUserRole() {
    return $_SESSION['user_role'] ?? 'guest';
}
?>