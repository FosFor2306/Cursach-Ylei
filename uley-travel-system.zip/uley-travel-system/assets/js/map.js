// Инициализация карты
function initMap() {
    const map = L.map('map').setView([55.7558, 37.6173], 2);
    
    // Добавляем слой OpenStreetMap
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);
    
    // Добавляем метки туров
    fetch('api/get_tours_map.php')
        .then(response => response.json())
        .then(tours => {
            tours.forEach(tour => {
                // Получаем координаты по названию города (упрощенно)
                getCoordinates(tour.city, tour.country)
                    .then(coords => {
                        if (coords) {
                            const marker = L.marker(coords).addTo(map);
                            marker.bindPopup(`
                                <b>${tour.title}</b><br>
                                ${tour.country}, ${tour.city}<br>
                                Цена: ${tour.price} ₽<br>
                                <a href="tour.php?id=${tour.id}">Подробнее</a>
                            `);
                        }
                    });
            });
        });
}

// Функция для получения координат (упрощенная)
async function getCoordinates(city, country) {
    try {
        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${city},${country}`);
        const data = await response.json();
        
        if (data.length > 0) {
            return [parseFloat(data[0].lat), parseFloat(data[0].lon)];
        }
    } catch (error) {
        console.error('Ошибка получения координат:', error);
    }
    return null;
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', initMap);