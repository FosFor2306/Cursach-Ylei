// Основные функции для сайта

document.addEventListener('DOMContentLoaded', function() {
    // Инициализация всех инструментов
    initTooltips();
    initModals();
    initFormValidation();
    initMobileMenu();
});

// Инициализация подсказок
function initTooltips() {
    const tooltips = document.querySelectorAll('[data-tooltip]');
    
    tooltips.forEach(element => {
        element.addEventListener('mouseenter', function(e) {
            const tooltipText = this.getAttribute('data-tooltip');
            const tooltip = document.createElement('div');
            tooltip.className = 'tooltip';
            tooltip.textContent = tooltipText;
            document.body.appendChild(tooltip);
            
            const rect = this.getBoundingClientRect();
            tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
            tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';
            
            this.tooltip = tooltip;
        });
        
        element.addEventListener('mouseleave', function() {
            if (this.tooltip) {
                this.tooltip.remove();
                this.tooltip = null;
            }
        });
    });
}

// Инициализация модальных окон
function initModals() {
    const modalTriggers = document.querySelectorAll('[data-modal]');
    const closeButtons = document.querySelectorAll('.modal-close');
    
    modalTriggers.forEach(trigger => {
        trigger.addEventListener('click', function() {
            const modalId = this.getAttribute('data-modal');
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.style.display = 'flex';
                document.body.style.overflow = 'hidden';
            }
        });
    });
    
    closeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const modal = this.closest('.modal');
            if (modal) {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        });
    });
    
    // Закрытие по клику вне модального окна
    window.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal')) {
            e.target.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });
}

// Валидация форм
function initFormValidation() {
    const forms = document.querySelectorAll('.needs-validation');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!form.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    });
}

// Мобильное меню
function initMobileMenu() {
    const menuToggle = document.querySelector('.menu-toggle');
    const mainNav = document.querySelector('.main-nav');
    
    if (menuToggle && mainNav) {
        menuToggle.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            this.classList.toggle('active');
        });
    }
}

// Функция для отображения уведомлений
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Анимация появления
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    // Автоматическое скрытие через 5 секунд
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 5000);
}

// Функция для подтверждения действия
function confirmAction(message) {
    return new Promise((resolve) => {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <h3>Подтверждение</h3>
                <p>${message}</p>
                <div class="modal-actions">
                    <button class="btn btn-secondary" id="confirmCancel">Отмена</button>
                    <button class="btn btn-danger" id="confirmOk">OK</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        document.body.style.overflow = 'hidden';
        
        modal.querySelector('#confirmCancel').addEventListener('click', function() {
            document.body.removeChild(modal);
            document.body.style.overflow = 'auto';
            resolve(false);
        });
        
        modal.querySelector('#confirmOk').addEventListener('click', function() {
            document.body.removeChild(modal);
            document.body.style.overflow = 'auto';
            resolve(true);
        });
    });
}

// Функция для загрузки файлов
function uploadFile(file, url, onProgress) {
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        const formData = new FormData();
        formData.append('file', file);
        
        xhr.upload.addEventListener('progress', onProgress);
        
        xhr.addEventListener('load', function() {
            if (xhr.status >= 200 && xhr.status < 300) {
                resolve(xhr.responseText);
            } else {
                reject(new Error('Upload failed'));
            }
        });
        
        xhr.addEventListener('error', reject);
        xhr.addEventListener('abort', reject);
        
        xhr.open('POST', url);
        xhr.send(formData);
    });
}

// Функция для форматирования даты
function formatDate(date, format = 'dd.mm.yyyy') {
    const d = new Date(date);
    const day = d.getDate().toString().padStart(2, '0');
    const month = (d.getMonth() + 1).toString().padStart(2, '0');
    const year = d.getFullYear();
    
    if (format === 'dd.mm.yyyy') {
        return `${day}.${month}.${year}`;
    } else if (format === 'yyyy-mm-dd') {
        return `${year}-${month}-${day}`;
    }
    
    return date;
}

// Функция для инициализации перетаскивания элементов (для капчи и других)
function initDragAndDrop(containerSelector, itemSelector, onDropCallback) {
    const containers = document.querySelectorAll(containerSelector);
    
    let dragItem = null;
    
    document.querySelectorAll(itemSelector).forEach(item => {
        item.setAttribute('draggable', true);
        
        item.addEventListener('dragstart', function() {
            dragItem = this;
            setTimeout(() => this.style.opacity = '0.4', 0);
        });
        
        item.addEventListener('dragend', function() {
            setTimeout(() => this.style.opacity = '1', 0);
            dragItem = null;
        });
    });
    
    containers.forEach(container => {
        container.addEventListener('dragover', function(e) {
            e.preventDefault();
        });
        
        container.addEventListener('dragenter', function(e) {
            e.preventDefault();
            this.style.backgroundColor = 'rgba(255, 215, 0, 0.1)';
        });
        
        container.addEventListener('dragleave', function() {
            this.style.backgroundColor = '';
        });
        
        container.addEventListener('drop', function(e) {
            e.preventDefault();
            this.style.backgroundColor = '';
            
            if (dragItem && this !== dragItem.parentNode) {
                this.appendChild(dragItem);
                
                if (onDropCallback) {
                    onDropCallback(this, dragItem);
                }
            }
        });
    });
}