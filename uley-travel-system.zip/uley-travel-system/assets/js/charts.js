// Функции для работы с графиками

class ChartManager {
    constructor() {
        this.charts = new Map();
    }
    
    // Создание круговой диаграммы
    createPieChart(canvasId, data, options = {}) {
        const ctx = document.getElementById(canvasId).getContext('2d');
        
        const defaultOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#fff'
                    }
                }
            }
        };
        
        const chartOptions = Object.assign({}, defaultOptions, options);
        
        const chart = new Chart(ctx, {
            type: 'pie',
            data: data,
            options: chartOptions
        });
        
        this.charts.set(canvasId, chart);
        return chart;
    }
    
    // Создание линейного графика
    createLineChart(canvasId, data, options = {}) {
        const ctx = document.getElementById(canvasId).getContext('2d');
        
        const defaultOptions = {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#fff'
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#fff'
                    }
                }
            },
            plugins: {
                legend: {
                    labels: {
                        color: '#fff'
                    }
                }
            }
        };
        
        const chartOptions = Object.assign({}, defaultOptions, options);
        
        const chart = new Chart(ctx, {
            type: 'line',
            data: data,
            options: chartOptions
        });
        
        this.charts.set(canvasId, chart);
        return chart;
    }
    
    // Создание столбчатой диаграммы
    createBarChart(canvasId, data, options = {}) {
        const ctx = document.getElementById(canvasId).getContext('2d');
        
        const defaultOptions = {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#fff'
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#fff'
                    }
                }
            },
            plugins: {
                legend: {
                    labels: {
                        color: '#fff'
                    }
                }
            }
        };
        
        const chartOptions = Object.assign({}, defaultOptions, options);
        
        const chart = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: chartOptions
        });
        
        this.charts.set(canvasId, chart);
        return chart;
    }
    
    // Обновление данных графика
    updateChart(canvasId, newData) {
        const chart = this.charts.get(canvasId);
        if (chart) {
            chart.data = newData;
            chart.update();
        }
    }
    
    // Уничтожение графика
    destroyChart(canvasId) {
        const chart = this.charts.get(canvasId);
        if (chart) {
            chart.destroy();
            this.charts.delete(canvasId);
        }
    }
    
    // Загрузка данных для графика с сервера
    async loadChartData(url, chartType, canvasId, options = {}) {
        try {
            const response = await fetch(url);
            const data = await response.json();
            
            switch (chartType) {
                case 'pie':
                    return this.createPieChart(canvasId, data, options);
                case 'line':
                    return this.createLineChart(canvasId, data, options);
                case 'bar':
                    return this.createBarChart(canvasId, data, options);
                default:
                    console.error('Unknown chart type:', chartType);
            }
        } catch (error) {
            console.error('Error loading chart data:', error);
        }
    }
}

// Глобальный экземпляр менеджера графиков
window.chartManager = new ChartManager();

// Функция для инициализации всех графиков на странице
function initCharts() {
    // Ищем все элементы с атрибутом data-chart
    const chartElements = document.querySelectorAll('[data-chart]');
    
    chartElements.forEach(element => {
        const chartType = element.getAttribute('data-chart');
        const canvasId = element.id;
        const dataUrl = element.getAttribute('data-url');
        const options = element.getAttribute('data-options') 
            ? JSON.parse(element.getAttribute('data-options')) 
            : {};
        
        if (dataUrl) {
            chartManager.loadChartData(dataUrl, chartType, canvasId, options);
        } else {
            // Если data-url не указан, пытаемся получить данные из data-attributes
            const labels = element.getAttribute('data-labels') 
                ? JSON.parse(element.getAttribute('data-labels')) 
                : [];
            const datasets = element.getAttribute('data-datasets') 
                ? JSON.parse(element.getAttribute('data-datasets')) 
                : [];
            
            const data = {
                labels: labels,
                datasets: datasets
            };
            
            switch (chartType) {
                case 'pie':
                    chartManager.createPieChart(canvasId, data, options);
                    break;
                case 'line':
                    chartManager.createLineChart(canvasId, data, options);
                    break;
                case 'bar':
                    chartManager.createBarChart(canvasId, data, options);
                    break;
            }
        }
    });
}

// Инициализация графиков при загрузке страницы
document.addEventListener('DOMContentLoaded', initCharts);