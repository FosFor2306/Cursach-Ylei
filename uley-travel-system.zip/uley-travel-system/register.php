<?php
session_start();
require_once 'config.php';

// Генерируем случайный порядок изображений капчи
$captchaImages = [1, 2, 3, 4];
shuffle($captchaImages); // Перемешиваем массив

// Сохраняем правильный порядок для проверки
$_SESSION['captcha_correct_order'] = [1, 1, 2, 2, 3, 3, 4, 4]; // 1-2 сверху, 3-4 снизу

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $full_name = $_POST['full_name'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $captchaOrder = $_POST['captcha_order'] ?? '';
    
// Проверка капчи - СТРОГИЙ порядок: 1, 2, 3, 4 слева направо, сверху вниз
$order = explode(',', $captchaOrder);

// Проверяем, что все 4 слота заполнены
if (count($order) !== 4 || in_array('', $order, true)) {
    $error = "Не все изображения размещены. Пожалуйста, разместите все 4 изображения.";
} else {
    // СТРОГАЯ проверка: слот 1 = 1, слот 2 = 2, слот 3 = 3, слот 4 = 4
    if ($order[0] != '1' || $order[1] != '2' || $order[2] != '3' || $order[3] != '4') {
        $error = "Неправильный порядок изображений!<br>Расположите картинки в порядке: 1, 2, 3, 4 (слева направо, сверху вниз).";
    } elseif ($password !== $confirm_password) {
            $error = "Пароли не совпадают";
        } else {
            // Проверяем, есть ли уже такой email
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            
            if ($stmt->fetch()) {
                $error = "Пользователь с таким email уже существует";
            } else {
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                
                $stmt = $pdo->prepare("INSERT INTO users (email, password_hash, role, full_name, phone) VALUES (?, ?, 'client', ?, ?)");
                if ($stmt->execute([$email, $password_hash, $full_name, $phone])) {
                    $success = "Регистрация успешна! Теперь вы можете войти.";
                } else {
                    $error = "Ошибка при регистрации";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация - Улей</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .captcha-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin: 20px 0;
        }
        .captcha-item {
            border: 2px solid var(--primary-yellow);
            border-radius: 5px;
            cursor: move;
            height: 120px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .captcha-target {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin: 20px 0;
            min-height: 250px;
            border: 2px dashed var(--primary-black);
            padding: 15px;
            background-color: rgba(255, 215, 0, 0.05);
        }
        .target-slot {
            border: 2px dashed #666;
            border-radius: 5px;
            min-height: 120px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: rgba(255, 255, 255, 0.05);
            transition: all 0.3s ease;
        }
        .target-slot.highlight {
            border-color: var(--primary-yellow);
            background-color: rgba(255, 215, 0, 0.1);
        }
        .target-slot.filled {
            border-style: solid;
            border-color: var(--primary-yellow);
        }
        .slot-label {
            color: #888;
            font-size: 14px;
        }
        .captcha-instructions {
            background-color: rgba(255, 215, 0, 0.1);
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            border-left: 3px solid var(--primary-yellow);
        }
        .captcha-instructions h4 {
            color: var(--primary-yellow);
            margin-top: 0;
        }
        .reset-captcha {
            margin-top: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-box">
            <div class="auth-header">
                <h2>Регистрация</h2>
                <img src="assets/images/logo.png" alt="Улей" height="40">
            </div>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
                <div class="auth-footer">
                    <a href="login.php" class="btn btn-primary">Войти</a>
                    <a href="index.php" class="btn btn-secondary">На главную</a>
                </div>
            <?php else: ?>
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="full_name">ФИО:</label>
                        <input type="text" id="full_name" name="full_name" required class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" required class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Телефон:</label>
                        <input type="tel" id="phone" name="phone" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Пароль:</label>
                        <input type="password" id="password" name="password" required class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Подтвердите пароль:</label>
                        <input type="password" id="confirm_password" name="confirm_password" required class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <div class="captcha-instructions">
                            <h4>Инструкция по капче:</h4>
                            <p>Перетащите изображения в правильном порядке:</p>
                            <ul>
                                <li><strong>Верхний ряд</strong> (слоты 1 и 2): картинки 1 и 2</li>
                                <li><strong>Нижний ряд</strong> (слоты 3 и 4): картинки 3 и 4</li>
                            </ul>
                        </div>
                        
                        <label>Капча:</label>
                        <div class="captcha-target" id="captchaTarget">
                            <div class="target-slot" data-slot="1">
                                <span class="slot-label">Слот 1 (верх)</span>
                            </div>
                            <div class="target-slot" data-slot="2">
                                <span class="slot-label">Слот 2 (верх)</span>
                            </div>
                            <div class="target-slot" data-slot="3">
                                <span class="slot-label">Слот 3 (низ)</span>
                            </div>
                            <div class="target-slot" data-slot="4">
                                <span class="slot-label">Слот 4 (низ)</span>
                            </div>
                        </div>
                        
                        <div class="captcha-container" id="captchaSource">
                            <div class="captcha-item" draggable="true" data-id="1" 
                                 style="background-image: url('assets/images/captcha/1.png')"
                                 title="Картинка 1"></div>
                            <div class="captcha-item" draggable="true" data-id="2"
                                 style="background-image: url('assets/images/captcha/2.png')"
                                 title="Картинка 2"></div>
                            <div class="captcha-item" draggable="true" data-id="3"
                                 style="background-image: url('assets/images/captcha/3.png')"
                                 title="Картинка 3"></div>
                            <div class="captcha-item" draggable="true" data-id="4"
                                 style="background-image: url('assets/images/captcha/4.png')"
                                 title="Картинка 4"></div>
                        </div>
                        
                        <div class="reset-captcha">
                            <button type="button" class="btn btn-sm btn-secondary" onclick="resetCaptcha()">
                                Сбросить капчу
                            </button>
                        </div>
                        
                        <input type="hidden" name="captcha_order" id="captchaOrder">
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-block" id="submitBtn" disabled>Зарегистрироваться</button>
                </form>
                
                <div class="auth-footer">
                    <p>Уже есть аккаунт? <a href="login.php">Войти</a></p>
                    <p><a href="index.php">Вернуться на главную</a></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
<script>
    document.addEventListener('DOMContentLoaded', function() {
        let draggedItem = null;
        const slots = {};
        let totalPlaced = 0;
        
        // Предупреждение для отладки
        console.log("Капча загружена. Правильный порядок: 1,2 сверху | 3,4 снизу");
        
        // Инициализация drag&drop
        document.querySelectorAll('.captcha-item').forEach(item => {
            item.addEventListener('dragstart', function(e) {
                draggedItem = this;
                const dataId = this.getAttribute('data-id');
                console.log("Начали перетаскивание картинки", dataId);
                
                setTimeout(() => {
                    this.style.opacity = '0.5';
                }, 0);
                
                // Добавляем класс всем слотам для подсветки
                document.querySelectorAll('.target-slot').forEach(slot => {
                    slot.classList.add('highlight');
                });
            });
            
            item.addEventListener('dragend', function() {
                setTimeout(() => {
                    this.style.opacity = '1';
                    draggedItem = null;
                    // Убираем подсветку
                    document.querySelectorAll('.target-slot').forEach(slot => {
                        slot.classList.remove('highlight');
                    });
                }, 0);
            });
        });
        
        document.querySelectorAll('.target-slot').forEach(slot => {
            slot.addEventListener('dragover', function(e) {
                e.preventDefault();
            });
            
            slot.addEventListener('dragenter', function(e) {
                e.preventDefault();
                this.classList.add('highlight');
            });
            
            slot.addEventListener('dragleave', function() {
                this.classList.remove('highlight');
            });
            
            slot.addEventListener('drop', function(e) {
                e.preventDefault();
                this.classList.remove('highlight');
                
                if (draggedItem) {
                    const slotNum = this.dataset.slot;
                    const itemId = draggedItem.dataset.id;
                    
                    console.log(`Помещаем картинку ${itemId} в слот ${slotNum}`);
                    
                    // Проверяем, не занят ли уже этот слот
                    if (slots[slotNum]) {
                        console.log("Слот уже занят");
                        return;
                    }
                    
                    // Проверяем, не используется ли уже эта картинка в другом слоте
                    for (let s in slots) {
                        if (slots[s] == itemId) {
                            console.log("Картинка уже используется в другом слоте");
                            return;
                        }
                    }
                    
                    // Заполняем слот
                    slots[slotNum] = itemId;
                    
                    // Очищаем слот
                    this.innerHTML = '';
                    
                    // Создаем изображение
                    const img = document.createElement('div');
                    img.className = 'captcha-preview';
                    img.style.cssText = `
                        width: 100%;
                        height: 100%;
                        background-image: url('assets/images/captcha/${itemId}.png');
                        background-size: contain;
                        background-repeat: no-repeat;
                        background-position: center;
                        border-radius: 5px;
                    `;
                    
                    // Добавляем номер для отладки
                    const label = document.createElement('div');
                    label.textContent = itemId;
                    label.style.cssText = `
                        position: absolute;
                        top: 5px;
                        left: 5px;
                        background: var(--primary-yellow);
                        color: var(--primary-black);
                        border-radius: 50%;
                        width: 24px;
                        height: 24px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        font-weight: bold;
                        font-size: 14px;
                    `;
                    
                    // Добавляем кнопку удаления
                    const removeBtn = document.createElement('button');
                    removeBtn.innerHTML = '×';
                    removeBtn.type = 'button';
                    removeBtn.style.cssText = `
                        position: absolute;
                        top: 5px;
                        right: 5px;
                        background: #ff4444;
                        color: white;
                        border: none;
                        border-radius: 50%;
                        width: 24px;
                        height: 24px;
                        cursor: pointer;
                        font-size: 16px;
                        line-height: 1;
                        z-index: 10;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
                    `;
                    removeBtn.title = 'Удалить';
                    
                    removeBtn.addEventListener('click', function(e) {
                        e.stopPropagation();
                        console.log("Удаляем картинку из слота", slotNum);
                        delete slots[slotNum];
                        this.parentElement.innerHTML = '<span class="slot-label">Слот ' + slotNum + 
                            (slotNum <= 2 ? ' (верх)' : ' (низ)') + '</span>';
                        this.parentElement.classList.remove('filled');
                        totalPlaced--;
                        updateCaptchaOrder();
                        updateSubmitButton();
                        
                        // Восстанавливаем исходную картинку
                        const originalItem = document.querySelector(`.captcha-item[data-id="${itemId}"]`);
                        if (originalItem) {
                            originalItem.style.opacity = '1';
                            originalItem.draggable = true;
                        }
                    });
                    
                    const container = document.createElement('div');
                    container.style.position = 'relative';
                    container.style.width = '100%';
                    container.style.height = '100%';
                    container.appendChild(img);
                    container.appendChild(label);
                    container.appendChild(removeBtn);
                    
                    this.appendChild(container);
                    this.classList.add('filled');
                    
                    // Помечаем исходную картинку как использованную
                    draggedItem.style.opacity = '0.3';
                    draggedItem.draggable = false;
                    
                    totalPlaced++;
                    updateCaptchaOrder();
                    updateSubmitButton();
                    
                    console.log("Текущее заполнение слотов:", slots);
                }
            });
        });
        
        function updateCaptchaOrder() {
            const order = [];
            for (let i = 1; i <= 4; i++) {
                order.push(slots[i] || '');
            }
            document.getElementById('captchaOrder').value = order.join(',');
            console.log("Порядок для отправки:", order.join(','));
        }
        
        function updateSubmitButton() {
            const btn = document.getElementById('submitBtn');
            if (totalPlaced === 4) {
                btn.disabled = false;
                // Показываем правильный порядок для отладки (уберите в продакшене)
                console.log("Все картинки размещены. Правильный порядок: 1,2 сверху | 3,4 снизу");
            } else {
                btn.disabled = true;
            }
        }
        
        window.resetCaptcha = function() {
            console.log("Сброс капчи");
            
            // Сбрасываем все слоты
            document.querySelectorAll('.target-slot').forEach(slot => {
                const slotNum = slot.dataset.slot;
                slot.innerHTML = '<span class="slot-label">Слот ' + slotNum + 
                    (slotNum <= 2 ? ' (верх)' : ' (низ)') + '</span>';
                slot.classList.remove('filled');
            });
            
            // Восстанавливаем исходные картинки
            document.querySelectorAll('.captcha-item').forEach(item => {
                item.style.opacity = '1';
                item.draggable = true;
            });
            
            // Очищаем данные
            for (let key in slots) {
                delete slots[key];
            }
            totalPlaced = 0;
            updateCaptchaOrder();
            updateSubmitButton();
        };
    });
</script>
</body>
</html>