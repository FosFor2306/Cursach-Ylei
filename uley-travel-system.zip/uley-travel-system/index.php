<?php
session_start();
require_once 'config.php';
require_once 'includes/auth.php';

if (isLoggedIn()) {
    header("Location: dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Улей - Туристическая фирма</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <style>
        :root {
            --primary-black: #1a1a1a;
            --primary-yellow: #FFD700;
            --accent-yellow: #FFED4E;
            --light-gray: #f5f5f5;
        }
    </style>
</head>
<body>
    <div class="container">
        <header class="header">
            <div class="logo">
                <img src="assets/images/logo.png" alt="Улей" height="50">
                <h1>Улей</h1>
                <span class="tagline">Туристическая фирма</span>
            </div>
            <nav class="main-nav">
                <?php if (!isLoggedIn()): ?>
                    <a href="login.php" class="btn btn-login">Вход</a>
                    <a href="register.php" class="btn btn-register">Регистрация</a>
                <?php else: ?>
                    <a href="dashboard.php" class="btn btn-dashboard">Личный кабинет</a>
                    <a href="logout.php" class="btn btn-logout">Выход</a>
                <?php endif; ?>
            </nav>
        </header>

        <main>
            <section class="hero">
                <div class="hero-content">
                    <h2>Путешествуйте с удовольствием!</h2>
                    <p>Откройте для себя лучшие туры по всему миру</p>
                    <a href="#tours" class="btn btn-primary">Смотреть туры</a>
                </div>
            </section>

            <section id="map-section">
                <h2>Наши направления</h2>
                <div id="map" style="height: 500px; border: 2px solid var(--primary-yellow); border-radius: 10px;"></div>
            </section>

            <section id="tours" class="tours-section">
                <h2>Популярные туры</h2>
                <div class="tours-grid">
                    <?php
                    $stmt = $pdo->query("SELECT * FROM tours WHERE is_available = 1 ORDER BY price LIMIT 6");
                    while ($tour = $stmt->fetch()):
                    ?>
                    <div class="tour-card">
                        <div class="tour-header">
                            <h3><?php echo htmlspecialchars($tour['title']); ?></h3>
                            <span class="tour-price"><?php echo number_format($tour['price'], 0, ',', ' '); ?> ₽</span>
                        </div>
                        <div class="tour-body">
                            <p><strong>Страна:</strong> <?php echo htmlspecialchars($tour['country']); ?></p>
                            <p><strong>Город:</strong> <?php echo htmlspecialchars($tour['city']); ?></p>
                            <p><?php echo substr(htmlspecialchars($tour['description']), 0, 100); ?>...</p>
                            <div class="tour-dates">
                                <span><?php echo date('d.m.Y', strtotime($tour['start_date'])); ?> - <?php echo date('d.m.Y', strtotime($tour['end_date'])); ?></span>
                            </div>
                        </div>
                        <div class="tour-footer">
                            <?php if (isLoggedIn()): ?>
                                <button class="btn btn-book" onclick="bookTour(<?php echo $tour['id']; ?>)">Забронировать</button>
                            <?php else: ?>
                                <a href="login.php" class="btn btn-book">Войти для бронирования</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </section>
        </main>

        <footer class="footer">
            <p>&copy; <?php echo date('Y'); ?> Улей - Туристическая фирма</p>
            <p>Телефон: +7 (XXX) XXX-XX-XX | Email: info@uley-travel.ru</p>
        </footer>
    </div>

    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="assets/js/map.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>