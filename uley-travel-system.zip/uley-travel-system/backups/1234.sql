DROP TABLE IF EXISTS `users`;
CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email VARCHAR(255) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(20) DEFAULT 'client' CHECK(role IN ('client', 'manager', 'admin')),
            full_name VARCHAR(255) NOT NULL,
            phone VARCHAR(50),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

INSERT INTO `users` (`id`, `email`, `password_hash`, `role`, `full_name`, `phone`, `created_at`) VALUES 
('1', 'admin@travelagency.com', '$2y$10$0ErBZsDg0KHT1N/TXJIh2uTh1OfVopCbx6JJXvE4l22nFYK9GRzk.', 'admin', 'Иван Петров', '+7 (900) 123-45-67', '2025-12-05 15:04:05'),
('2', 'manager1@travelagency.com', '$2y$10$0ErBZsDg0KHT1N/TXJIh2uTh1OfVopCbx6JJXvE4l22nFYK9GRzk.', 'manager', 'Елена Сидорова', '+7 (901) 234-56-78', '2025-12-05 15:04:05'),
('3', 'manager2@travelagency.com', '$2y$10$0ErBZsDg0KHT1N/TXJIh2uTh1OfVopCbx6JJXvE4l22nFYK9GRzk.', 'manager', 'Алексей Козлов', '+7 (902) 345-67-89', '2025-12-05 15:04:05'),
('4', 'client1@mail.com', '$2y$10$0ErBZsDg0KHT1N/TXJIh2uTh1OfVopCbx6JJXvE4l22nFYK9GRzk.', 'client', 'Мария Иванова', '+7 (903) 456-78-90', '2025-12-05 15:04:05'),
('5', 'client2@mail.com', '$2y$10$0ErBZsDg0KHT1N/TXJIh2uTh1OfVopCbx6JJXvE4l22nFYK9GRzk.', 'client', 'Сергей Смирнов', '+7 (904) 567-89-01', '2025-12-05 15:04:05');

DROP TABLE IF EXISTS `sqlite_sequence`;
CREATE TABLE sqlite_sequence(name,seq);

INSERT INTO `sqlite_sequence` (`name`, `seq`) VALUES 
('users', '5'),
('tours', '5'),
('bookings', '3'),
('messages', '3'),
('payments', '2'),
('reports', '2');

DROP TABLE IF EXISTS `tours`;
CREATE TABLE tours (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            country VARCHAR(100) NOT NULL,
            city VARCHAR(100) NOT NULL,
            price DECIMAL(10,2) NOT NULL,
            start_date DATE,
            end_date DATE,
            is_available BOOLEAN DEFAULT 1,
            created_by INTEGER NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES users(id)
        );

INSERT INTO `tours` (`id`, `title`, `description`, `country`, `city`, `price`, `start_date`, `end_date`, `is_available`, `created_by`, `created_at`) VALUES 
('1', 'Отдых в Турции', 'Прекрасный отдых на берегу Средиземного моря. Все включено!', 'Турция', 'Анталия', '45000', '2024-06-15', '2024-06-25', '1', '1', '2025-12-05 15:04:05'),
('2', 'Экскурсия по Италии', 'Незабываемое путешествие по самым красивым городам Италии', 'Италия', 'Рим', '78000', '2024-07-10', '2024-07-20', '1', '2', '2025-12-05 15:04:05'),
('3', 'Горнолыжный курорт', 'Катание на лыжах в Альпах для всей семьи', 'Франция', 'Шамони', '62000', '2024-12-20', '2024-12-30', '1', '3', '2025-12-05 15:04:05'),
('4', 'Пляжный отдых в Греции', 'Расслабляющий отдых на греческих островах', 'Греция', 'Санторини', '51000', '2024-08-05', '2024-08-15', '1', '1', '2025-12-05 15:04:05'),
('5', 'Экзотический Таиланд', 'Погружение в культуру и природу Таиланда', 'Таиланд', 'Пхукет', '89000', '2024-09-01', '2024-09-14', '1', '2', '2025-12-05 15:04:05');

DROP TABLE IF EXISTS `bookings`;
CREATE TABLE bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            tour_id INTEGER NOT NULL,
            manager_id INTEGER,
            status VARCHAR(20) DEFAULT 'new' CHECK(status IN ('new', 'confirmed', 'rejected', 'paid', 'completed')),
            persons_count INTEGER DEFAULT 1,
            total_price DECIMAL(10,2) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (tour_id) REFERENCES tours(id),
            FOREIGN KEY (manager_id) REFERENCES users(id)
        );

INSERT INTO `bookings` (`id`, `user_id`, `tour_id`, `manager_id`, `status`, `persons_count`, `total_price`, `created_at`, `updated_at`) VALUES 
('1', '4', '1', '2', 'confirmed', '2', '90000', '2025-12-05 15:04:05', '2025-12-05 15:04:05'),
('2', '5', '2', '3', 'paid', '1', '78000', '2025-12-05 15:04:05', '2025-12-05 15:04:05'),
('3', '4', '3', NULL, 'new', '2', '124000', '2025-12-05 15:04:05', '2025-12-05 15:04:05');

DROP TABLE IF EXISTS `messages`;
CREATE TABLE messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            message_text TEXT NOT NULL,
            is_read BOOLEAN DEFAULT 0,
            sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (booking_id) REFERENCES bookings(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

INSERT INTO `messages` (`id`, `booking_id`, `user_id`, `message_text`, `is_read`, `sent_at`) VALUES 
('1', '1', '4', 'Здравствуйте! Хотел бы уточнить детали по трансферу', '0', '2025-12-05 15:04:05'),
('2', '1', '2', 'Добрый день! Трансфер включен в стоимость тура', '1', '2025-12-05 15:04:05'),
('3', '2', '5', 'Когда нужно будет внести предоплату?', '0', '2025-12-05 15:04:05');

DROP TABLE IF EXISTS `payments`;
CREATE TABLE payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id INTEGER NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            payment_method VARCHAR(20) CHECK(payment_method IN ('card', 'cash', 'bank_transfer')),
            status VARCHAR(20) DEFAULT 'pending' CHECK(status IN ('pending', 'completed', 'failed', 'refunded')),
            transaction_id VARCHAR(255),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (booking_id) REFERENCES bookings(id)
        );

INSERT INTO `payments` (`id`, `booking_id`, `amount`, `payment_method`, `status`, `transaction_id`, `created_at`) VALUES 
('1', '1', '30000', 'card', 'completed', 'trx_00123456', '2025-12-05 15:04:05'),
('2', '2', '23400', 'bank_transfer', 'completed', 'trx_00123457', '2025-12-05 15:04:05');

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id INTEGER NOT NULL UNIQUE,
            user_id INTEGER NOT NULL,
            rating INTEGER CHECK(rating BETWEEN 1 AND 5),
            comment TEXT,
            is_approved BOOLEAN DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (booking_id) REFERENCES bookings(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

DROP TABLE IF EXISTS `reports`;
CREATE TABLE reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            report_type VARCHAR(20) CHECK(report_type IN ('sales', 'bookings', 'users', 'tours', 'financial')),
            report_name VARCHAR(255) NOT NULL,
            period_start DATE NOT NULL,
            period_end DATE NOT NULL,
            generated_by INTEGER NOT NULL,
            file_path VARCHAR(500),
            parameters TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (generated_by) REFERENCES users(id)
        );

INSERT INTO `reports` (`id`, `report_type`, `report_name`, `period_start`, `period_end`, `generated_by`, `file_path`, `parameters`, `created_at`) VALUES 
('1', 'sales', 'Отчет по продажам за июнь', '2024-06-01', '2024-06-30', '1', '/reports/sales_june2024.pdf', '{"department": "all", "include_details": true}', '2025-12-05 15:04:05'),
('2', 'bookings', 'Бронирования по менеджерам', '2024-01-01', '2024-06-30', '2', '/reports/bookings_q2_2024.xlsx', '{"group_by": "manager", "status": ["confirmed", "paid"]}', '2025-12-05 15:04:05');

DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE login_attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email VARCHAR(255) NOT NULL,
            attempts INTEGER DEFAULT 0,
            last_attempt INTEGER,
            lock_until INTEGER
        );

DROP TABLE IF EXISTS `action_logs`;
CREATE TABLE action_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            action VARCHAR(255) NOT NULL,
            details TEXT,
            ip_address VARCHAR(45),
            user_agent TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

