<?php
session_start();
require_once 'config.php';
require_once 'includes/auth.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Получение статистики для разных ролей с проверкой на NULL
if ($user_role == 'admin') {
    $total_users = $pdo->query("SELECT COUNT(*) as count FROM users")->fetch()['count'];
    $total_tours = $pdo->query("SELECT COUNT(*) as count FROM tours")->fetch()['count'];
    $total_bookings = $pdo->query("SELECT COUNT(*) as count FROM bookings")->fetch()['count'];
    
    // Исправление: проверяем на NULL перед использованием
    $revenue_result = $pdo->query("SELECT SUM(total_price) as total FROM bookings WHERE status = 'completed'")->fetch();
    $total_revenue = $revenue_result['total'] ? (float)$revenue_result['total'] : 0;
} elseif ($user_role == 'manager') {
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM bookings WHERE manager_id = ?");
    $stmt->execute([$user_id]);
    $my_bookings = $stmt->fetch()['count'];
    
    $pending_messages_result = $pdo->query("SELECT COUNT(*) as count FROM messages WHERE is_read = 0")->fetch();
    $pending_messages = $pending_messages_result['count'];
} else {
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM bookings WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $result = $stmt->fetch();
    $my_bookings = $result['count'];
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM reviews WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $result = $stmt->fetch();
    $my_reviews = $result['count'];
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет - Улей</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container">
        <?php include 'includes/header.php'; ?>
        
        <main>
            <h2>Личный кабинет</h2>
            
            <div class="dashboard-grid">
                <div class="dashboard-card">
                    <h3>Статистика</h3>
                    <?php if ($user_role == 'admin'): ?>
                        <div class="stat">Пользователей: <span class="stat-number"><?php echo $total_users; ?></span></div>
                        <div class="stat">Туров: <span class="stat-number"><?php echo $total_tours; ?></span></div>
                        <div class="stat">Бронирований: <span class="stat-number"><?php echo $total_bookings; ?></span></div>
                        <div class="stat">Выручка: <span class="stat-number"><?php echo number_format($total_revenue, 0, ',', ' '); ?> ₽</span></div>
                    <?php elseif ($user_role == 'manager'): ?>
                        <div class="stat">Мои бронирования: <span class="stat-number"><?php echo $my_bookings; ?></span></div>
                        <div class="stat">Новых сообщений: <span class="stat-number"><?php echo $pending_messages; ?></span></div>
                    <?php else: ?>
                        <div class="stat">Мои бронирования: <span class="stat-number"><?php echo $my_bookings; ?></span></div>
                        <div class="stat">Мои отзывы: <span class="stat-number"><?php echo $my_reviews; ?></span></div>
                    <?php endif; ?>
                </div>

                <div class="dashboard-card">
                    <h3>Быстрые действия</h3>
                    <div class="quick-actions">
                        <?php if ($user_role == 'admin'): ?>
                            <a href="admin/" class="btn btn-secondary btn-block">Админ панель</a>
                            <a href="backup.php" class="btn btn-success btn-block">Создать бэкап</a>
                        <?php elseif ($user_role == 'manager'): ?>
                            <a href="manager/" class="btn btn-secondary btn-block">Панель менеджера</a>
                        <?php else: ?>
                            <a href="client/tours.php" class="btn btn-secondary btn-block">Смотреть туры</a>
                            <a href="client/my-bookings.php" class="btn btn-secondary btn-block">Мои бронирования</a>
                        <?php endif; ?>
                        <a href="logout.php" class="btn btn-danger btn-block">Выйти</a>
                    </div>
                </div>

                <div class="dashboard-card chart-container">
                    <h3>Статистика бронирований</h3>
                    <canvas id="bookingsChart"></canvas>
                </div>
            </div>
        </main>
        
        <?php include 'includes/footer.php'; ?>
    </div>

    <script>
        // График бронирований
        const ctx = document.getElementById('bookingsChart').getContext('2d');
        const bookingsChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн'],
                datasets: [{
                    label: 'Бронирования',
                    data: [12, 19, 15, 25, 22, 30],
                    backgroundColor: 'rgba(255, 215, 0, 0.7)',
                    borderColor: 'rgba(255, 215, 0, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>