<?php
session_start();
require_once 'config.php';
require_once 'includes/auth.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

if (!isAdmin()) {
    die("Доступ запрещен. Только администратор может создавать бэкапы.");
}

$backup_dir = 'backups/';
if (!file_exists($backup_dir)) {
    mkdir($backup_dir, 0755, true);
}

// Создание бэкапа
if (isset($_POST['create_backup'])) {
    $backup_file = $backup_dir . 'backup_' . date('Y-m-d_H-i-s') . '.sql';
    
    // Получаем все таблицы
    $tables = $pdo->query("SELECT name FROM sqlite_master WHERE type='table'")->fetchAll();
    
    $backup_content = "";
    
    foreach ($tables as $table) {
        $table_name = $table['name'];
        
        // Структура таблицы
        $backup_content .= "DROP TABLE IF EXISTS `$table_name`;\n";
        $create_table = $pdo->query("SELECT sql FROM sqlite_master WHERE type='table' AND name='$table_name'")->fetch();
        $backup_content .= $create_table['sql'] . ";\n\n";
        
        // Данные таблицы
        $rows = $pdo->query("SELECT * FROM `$table_name`")->fetchAll(PDO::FETCH_ASSOC);
        
        if (count($rows) > 0) {
            $columns = array_keys($rows[0]);
            $backup_content .= "INSERT INTO `$table_name` (`" . implode('`, `', $columns) . "`) VALUES \n";
            
            $insert_values = [];
            foreach ($rows as $row) {
                $values = array_map(function($value) use ($pdo) {
                    if ($value === null) return 'NULL';
                    return $pdo->quote($value);
                }, array_values($row));
                
                $insert_values[] = "(" . implode(', ', $values) . ")";
            }
            
            $backup_content .= implode(",\n", $insert_values) . ";\n\n";
        }
    }
    
    // Сохраняем файл
    if (file_put_contents($backup_file, $backup_content)) {
        $success = "Бэкап успешно создан: " . basename($backup_file);
        
        // Запись в лог
        logAction($pdo, $_SESSION['user_id'], 'create_backup', 'Создан бэкап базы данных');
    } else {
        $error = "Ошибка при создании бэкапа";
    }
}

// Переименование бэкапа
if (isset($_POST['rename_backup'])) {
    $old_name = $_POST['old_name'];
    $new_name = $_POST['new_name'];
    
    // Проверка расширения
    if (pathinfo($new_name, PATHINFO_EXTENSION) !== 'sql') {
        $new_name .= '.sql';
    }
    
    $old_path = $backup_dir . $old_name;
    $new_path = $backup_dir . $new_name;
    
    if (file_exists($old_path) && !file_exists($new_path)) {
        if (rename($old_path, $new_path)) {
            $success = "Файл успешно переименован";
            logAction($pdo, $_SESSION['user_id'], 'rename_backup', "Переименован файл: $old_name -> $new_name");
        } else {
            $error = "Ошибка при переименовании файла";
        }
    } else {
        $error = "Файл не существует или новое имя уже занято";
    }
}

// Удаление бэкапа
if (isset($_GET['delete_backup'])) {
    $filename = $_GET['delete_backup'];
    $filepath = $backup_dir . $filename;
    
    if (file_exists($filepath) && unlink($filepath)) {
        $success = "Бэкап успешно удален";
        logAction($pdo, $_SESSION['user_id'], 'delete_backup', "Удален файл: $filename");
    } else {
        $error = "Ошибка при удалении файла";
    }
}

// Список существующих бэкапов
$backups = [];
if (is_dir($backup_dir)) {
    $files = scandir($backup_dir);
    foreach ($files as $file) {
        if (pathinfo($file, PATHINFO_EXTENSION) === 'sql') {
            $backups[] = [
                'name' => $file,
                'size' => filesize($backup_dir . $file),
                'date' => filemtime($backup_dir . $file)
            ];
        }
    }
    
    // Сортировка по дате (новые сначала)
    usort($backups, function($a, $b) {
        return $b['date'] - $a['date'];
    });
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Бэкапирование - Улей</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <?php include 'includes/header.php'; ?>
        
        <main>
            <h2>Бэкапирование базы данных</h2>
            
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="card">
                <h3>Создать новый бэкап</h3>
                <form method="POST">
                    <p>Создайте резервную копию всей базы данных.</p>
                    <button type="submit" name="create_backup" class="btn btn-primary">
                        Создать бэкап
                    </button>
                </form>
            </div>
            
            <div class="card mt-4">
                <h3>Существующие бэкапы</h3>
                
                <?php if (count($backups) > 0): ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Имя файла</th>
                                <th>Размер</th>
                                <th>Дата создания</th>
                                <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($backups as $backup): ?>
                            <tr>
                                <td>
                                    <?php echo htmlspecialchars($backup['name']); ?>
                                </td>
                                <td><?php echo formatBytes($backup['size']); ?></td>
                                <td><?php echo date('d.m.Y H:i:s', $backup['date']); ?></td>
                                <td>
                                    <a href="<?php echo $backup_dir . $backup['name']; ?>" 
                                       class="btn btn-sm btn-secondary" download>Скачать</a>
                                    <button class="btn btn-sm btn-warning" 
                                            onclick="showRenameForm('<?php echo $backup['name']; ?>')">Переименовать</button>
                                    <a href="?delete_backup=<?php echo urlencode($backup['name']); ?>" 
                                       class="btn btn-sm btn-danger"
                                       onclick="return confirm('Удалить этот бэкап?')">Удалить</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>Бэкапы отсутствуют</p>
                <?php endif; ?>
            </div>
            
            <!-- Форма переименования (скрытая по умолчанию) -->
            <div id="renameForm" class="card mt-4" style="display: none;">
                <h3>Переименовать файл</h3>
                <form method="POST" action="">
                    <input type="hidden" name="old_name" id="oldName">
                    <div class="form-group">
                        <label>Новое имя файла:</label>
                        <input type="text" name="new_name" id="newName" class="form-control" 
                               placeholder="backup_2024-12-01.sql" required>
                        <small class="text-muted">Укажите имя файла с расширением .sql</small>
                    </div>
                    <button type="submit" name="rename_backup" class="btn btn-primary">Переименовать</button>
                    <button type="button" class="btn btn-secondary" onclick="hideRenameForm()">Отмена</button>
                </form>
            </div>
        </main>
    </div>
    
    <script>
        function showRenameForm(filename) {
            document.getElementById('oldName').value = filename;
            document.getElementById('newName').value = filename.replace('.sql', '');
            document.getElementById('renameForm').style.display = 'block';
            document.getElementById('renameForm').scrollIntoView({ behavior: 'smooth' });
        }
        
        function hideRenameForm() {
            document.getElementById('renameForm').style.display = 'none';
        }
        
        function formatBytes(bytes, decimals = 2) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const dm = decimals < 0 ? 0 : decimals;
            const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
        }
    </script>
</body>
</html>

<?php
function formatBytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= pow(1024, $pow);
    
    return round($bytes, $precision) . ' ' . $units[$pow];
}
?>