<?php

// Используем SQLite вместо MySQL
$databaseFile = __DIR__ . '/../database/travel_agency.db';
$databaseDir = dirname($databaseFile);

// Создаем папку если не существует
if (!file_exists($databaseDir)) {
    mkdir($databaseDir, 0755, true);
}

try {
    $pdo = new PDO("sqlite:" . $databaseFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // Создаем таблицы если их нет
    createTables($pdo);
    
    // Добавляем тестовые данные
    insertTestData($pdo);
    
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

function createTables($pdo) {
    // Таблица пользователей
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email VARCHAR(255) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(20) DEFAULT 'client' CHECK(role IN ('client', 'manager', 'admin')),
            full_name VARCHAR(255) NOT NULL,
            phone VARCHAR(50),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");
    
    // Таблица туров
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS tours (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            country VARCHAR(100) NOT NULL,
            city VARCHAR(100) NOT NULL,
            price DECIMAL(10,2) NOT NULL,
            start_date DATE,
            end_date DATE,
            is_available BOOLEAN DEFAULT 1,
            created_by INTEGER NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES users(id)
        )
    ");
    
    // Таблица бронирований
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            tour_id INTEGER NOT NULL,
            manager_id INTEGER,
            status VARCHAR(20) DEFAULT 'new' CHECK(status IN ('new', 'confirmed', 'rejected', 'paid', 'completed')),
            persons_count INTEGER DEFAULT 1,
            total_price DECIMAL(10,2) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (tour_id) REFERENCES tours(id),
            FOREIGN KEY (manager_id) REFERENCES users(id)
        )
    ");
    
    // Таблица сообщений
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            message_text TEXT NOT NULL,
            is_read BOOLEAN DEFAULT 0,
            sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (booking_id) REFERENCES bookings(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ");
    
    // Таблица платежей
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id INTEGER NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            payment_method VARCHAR(20) CHECK(payment_method IN ('card', 'cash', 'bank_transfer')),
            status VARCHAR(20) DEFAULT 'pending' CHECK(status IN ('pending', 'completed', 'failed', 'refunded')),
            transaction_id VARCHAR(255),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (booking_id) REFERENCES bookings(id)
        )
    ");
    
    // Таблица отзывов
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id INTEGER NOT NULL UNIQUE,
            user_id INTEGER NOT NULL,
            rating INTEGER CHECK(rating BETWEEN 1 AND 5),
            comment TEXT,
            is_approved BOOLEAN DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (booking_id) REFERENCES bookings(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ");
    
    // Таблица отчетов
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            report_type VARCHAR(20) CHECK(report_type IN ('sales', 'bookings', 'users', 'tours', 'financial')),
            report_name VARCHAR(255) NOT NULL,
            period_start DATE NOT NULL,
            period_end DATE NOT NULL,
            generated_by INTEGER NOT NULL,
            file_path VARCHAR(500),
            parameters TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (generated_by) REFERENCES users(id)
        )
    ");
    
    // Таблица попыток входа
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS login_attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email VARCHAR(255) NOT NULL,
            attempts INTEGER DEFAULT 0,
            last_attempt INTEGER,
            lock_until INTEGER
        )
    ");
    
    // Таблица логов действий
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS action_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            action VARCHAR(255) NOT NULL,
            details TEXT,
            ip_address VARCHAR(45),
            user_agent TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ");
}

function insertTestData($pdo) {
    // Проверяем, есть ли уже данные
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
    $result = $stmt->fetch();
    
    if ($result['count'] == 0) {
        // Добавляем тестовых пользователей
        $users = [
            ['admin@travelagency.com', '$2y$10$r8X5w7T6e4R3t2Y1u0iV.O', 'admin', 'Иван Петров', '+7 (900) 123-45-67'],
            ['manager1@travelagency.com', '$2y$10$q9W8e7R6t5Y4u3I2o1P.Z', 'manager', 'Елена Сидорова', '+7 (901) 234-56-78'],
            ['manager2@travelagency.com', '$2y$10$a8S7d6F5g4H3j2K1l0M.X', 'manager', 'Алексей Козлов', '+7 (902) 345-67-89'],
            ['client1@mail.com', '$2y$10$z1X2c3V4b5N6m7L8k9J.H', 'client', 'Мария Иванова', '+7 (903) 456-78-90'],
            ['client2@mail.com', '$2y$10$p0O9i8U7y6T5r4E3w2Q.F', 'client', 'Сергей Смирнов', '+7 (904) 567-89-01']
        ];
        
        $stmt = $pdo->prepare("INSERT INTO users (email, password_hash, role, full_name, phone) VALUES (?, ?, ?, ?, ?)");
        foreach ($users as $user) {
            $stmt->execute($user);
        }
        
        // Добавляем тестовые туры
        $tours = [
            ['Отдых в Турции', 'Прекрасный отдых на берегу Средиземного моря. Все включено!', 'Турция', 'Анталия', 45000.00, '2024-06-15', '2024-06-25', 1, 1],
            ['Экскурсия по Италии', 'Незабываемое путешествие по самым красивым городам Италии', 'Италия', 'Рим', 78000.00, '2024-07-10', '2024-07-20', 1, 2],
            ['Горнолыжный курорт', 'Катание на лыжах в Альпах для всей семьи', 'Франция', 'Шамони', 62000.00, '2024-12-20', '2024-12-30', 1, 3],
            ['Пляжный отдых в Греции', 'Расслабляющий отдых на греческих островах', 'Греция', 'Санторини', 51000.00, '2024-08-05', '2024-08-15', 1, 1],
            ['Экзотический Таиланд', 'Погружение в культуру и природу Таиланда', 'Таиланд', 'Пхукет', 89000.00, '2024-09-01', '2024-09-14', 1, 2]
        ];
        
        $stmt = $pdo->prepare("INSERT INTO tours (title, description, country, city, price, start_date, end_date, is_available, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($tours as $tour) {
            $stmt->execute($tour);
        }
        
        // Добавляем тестовые бронирования
        $bookings = [
            [4, 1, 2, 'confirmed', 2, 90000.00],
            [5, 2, 3, 'paid', 1, 78000.00],
            [4, 3, null, 'new', 2, 124000.00]
        ];
        
        $stmt = $pdo->prepare("INSERT INTO bookings (user_id, tour_id, manager_id, status, persons_count, total_price) VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($bookings as $booking) {
            $stmt->execute($booking);
        }
        
        // Добавляем тестовые сообщения
        $messages = [
            [1, 4, 'Здравствуйте! Хотел бы уточнить детали по трансферу', 0],
            [1, 2, 'Добрый день! Трансфер включен в стоимость тура', 1],
            [2, 5, 'Когда нужно будет внести предоплату?', 0]
        ];
        
        $stmt = $pdo->prepare("INSERT INTO messages (booking_id, user_id, message_text, is_read) VALUES (?, ?, ?, ?)");
        foreach ($messages as $message) {
            $stmt->execute($message);
        }
        
        // Добавляем тестовые платежи
        $payments = [
            [1, 30000.00, 'card', 'completed', 'trx_00123456'],
            [2, 23400.00, 'bank_transfer', 'completed', 'trx_00123457']
        ];
        
        $stmt = $pdo->prepare("INSERT INTO payments (booking_id, amount, payment_method, status, transaction_id) VALUES (?, ?, ?, ?, ?)");
        foreach ($payments as $payment) {
            $stmt->execute($payment);
        }
        
        // Добавляем тестовые отчеты
        $reports = [
            ['sales', 'Отчет по продажам за июнь', '2024-06-01', '2024-06-30', 1, '/reports/sales_june2024.pdf', '{"department": "all", "include_details": true}'],
            ['bookings', 'Бронирования по менеджерам', '2024-01-01', '2024-06-30', 2, '/reports/bookings_q2_2024.xlsx', '{"group_by": "manager", "status": ["confirmed", "paid"]}']
        ];
        
        $stmt = $pdo->prepare("INSERT INTO reports (report_type, report_name, period_start, period_end, generated_by, file_path, parameters) VALUES (?, ?, ?, ?, ?, ?, ?)");
        foreach ($reports as $report) {
            $stmt->execute($report);
        }
    }
}

// Функция для логирования действий
function logAction($pdo, $user_id, $action, $details = null) {
    $stmt = $pdo->prepare("INSERT INTO action_logs (user_id, action, details, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([
        $user_id, 
        $action, 
        $details, 
        $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
    ]);
}

// ВРЕМЕННЫЙ СБРОС ПАРОЛЕЙ ДЛЯ ТЕСТИРОВАНИЯ
function resetAllPasswords($pdo) {
    $password = password_hash('123456', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET password_hash = ?");
    if ($stmt->execute([$password])) {
        // Только логируем, не выводим
        error_log("Все пароли сброшены на: 123456");
    }
}
// Раскомментируйте следующую строку для сброса паролей:
resetAllPasswords($pdo);

// УДАЛИТЕ ИЛИ ЗАКОММЕНТИРУЙТЕ ЭТУ СТРОКУ:
// echo "<!-- Пароли сброшены на: 123456 -->";

?>