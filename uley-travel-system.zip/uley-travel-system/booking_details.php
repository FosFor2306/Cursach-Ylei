<?php
session_start();
require_once 'config.php';

// Удалите отладочный вывод перед любыми заголовками!
// echo '<pre>'; print_r($_SESSION); echo '</pre>'; // УДАЛИТЕ ЭТУ СТРОКУ!

// Проверяем, авторизован ли пользователь
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role']; // Измените с 'role' на 'user_role'

// Получаем ID бронирования из GET параметра
$booking_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($booking_id == 0) {
    die("Не указан идентификатор бронирования");
}

// Инициализируем переменные
$booking = null;

// Получаем информацию о бронировании с проверкой прав
if ($user_role == 'admin') {
    // Админ видит все бронирования
    $stmt = $pdo->prepare("
        SELECT b.*, 
               u.full_name as user_name, u.email as user_email, u.phone as user_phone,
               t.title as tour_title, t.description as tour_description, 
               t.country, t.city, t.price as tour_price,
               m.full_name as manager_name
        FROM bookings b
        JOIN users u ON b.user_id = u.id
        JOIN tours t ON b.tour_id = t.id
        LEFT JOIN users m ON b.manager_id = m.id
        WHERE b.id = ?
    ");
    $stmt->execute([$booking_id]);
    $booking = $stmt->fetch();
} elseif ($user_role == 'manager') {
    // Менеджер видит свои бронирования или неназначенные
    $stmt = $pdo->prepare("
        SELECT b.*, 
               u.full_name as user_name, u.email as user_email, u.phone as user_phone,
               t.title as tour_title, t.description as tour_description, 
               t.country, t.city, t.price as tour_price,
               m.full_name as manager_name
        FROM bookings b
        JOIN users u ON b.user_id = u.id
        JOIN tours t ON b.tour_id = t.id
        LEFT JOIN users m ON b.manager_id = m.id
        WHERE b.id = ? AND (b.manager_id = ? OR b.manager_id IS NULL OR b.manager_id = '')
    ");
    $stmt->execute([$booking_id, $user_id]);
    $booking = $stmt->fetch();
} elseif ($user_role == 'client') {
    // Клиент видит только свои бронирования
    $stmt = $pdo->prepare("
        SELECT b.*, 
               u.full_name as user_name, u.email as user_email, u.phone as user_phone,
               t.title as tour_title, t.description as tour_description, 
               t.country, t.city, t.price as tour_price,
               m.full_name as manager_name
        FROM bookings b
        JOIN users u ON b.user_id = u.id
        JOIN tours t ON b.tour_id = t.id
        LEFT JOIN users m ON b.manager_id = m.id
        WHERE b.id = ? AND b.user_id = ?
    ");
    $stmt->execute([$booking_id, $user_id]);
    $booking = $stmt->fetch();
} else {
    // Если роль не распознана, то выходим
    header("Location: login.php");
    exit();
}

if (!$booking) {
    die("Бронирование не найдено или у вас нет прав для его просмотра");
}

// Получаем сообщения по этому бронированию
$messages_stmt = $pdo->prepare("
    SELECT m.*, u.full_name as sender_name, u.role as sender_role
    FROM messages m
    JOIN users u ON m.user_id = u.id
    WHERE m.booking_id = ?
    ORDER BY m.sent_at ASC
");
$messages_stmt->execute([$booking_id]);
$messages = $messages_stmt->fetchAll();

// Получаем платежи по этому бронированию
$payments_stmt = $pdo->prepare("
    SELECT * FROM payments 
    WHERE booking_id = ? 
    ORDER BY created_at ASC
");
$payments_stmt->execute([$booking_id]);
$payments = $payments_stmt->fetchAll();

// Получаем отзыв по этому бронированию
$review_stmt = $pdo->prepare("
    SELECT * FROM reviews WHERE booking_id = ?
");
$review_stmt->execute([$booking_id]);
$review = $review_stmt->fetch();

// Отправка нового сообщения
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $message_text = trim($_POST['message_text']);
    
    if (!empty($message_text)) {
        $stmt = $pdo->prepare("
            INSERT INTO messages (booking_id, user_id, message_text, sent_at) 
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->execute([$booking_id, $user_id, $message_text]);
        
        // Перенаправляем, чтобы избежать повторной отправки
        header("Location: booking_details.php?id=" . $booking_id);
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Детали бронирования #<?php echo $booking['id']; ?> - Улей</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <?php include 'includes/header.php'; ?>
        
        <main>
            <h2>Детали бронирования #<?php echo $booking['id']; ?></h2>
            
            <div class="booking-info">
                <div class="info-section">
                    <h3>Информация о туре</h3>
                    <p><strong>Название:</strong> <?php echo htmlspecialchars($booking['tour_title']); ?></p>
                    <p><strong>Страна:</strong> <?php echo htmlspecialchars($booking['country']); ?></p>
                    <p><strong>Город:</strong> <?php echo htmlspecialchars($booking['city']); ?></p>
                    <p><strong>Описание:</strong> <?php echo htmlspecialchars($booking['tour_description']); ?></p>
                </div>
                
                <div class="info-section">
                    <h3>Информация о клиенте</h3>
                    <p><strong>ФИО:</strong> <?php echo htmlspecialchars($booking['user_name']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($booking['user_email']); ?></p>
                    <p><strong>Телефон:</strong> <?php echo htmlspecialchars($booking['user_phone']); ?></p>
                </div>
                
                <div class="info-section">
                    <h3>Детали бронирования</h3>
                    <p><strong>Количество человек:</strong> <?php echo $booking['persons_count']; ?></p>
                    <p><strong>Общая стоимость:</strong> <?php echo number_format($booking['total_price'], 0, ',', ' '); ?> ₽</p>
                    <p><strong>Статус:</strong> 
                        <?php 
                        $status_labels = [
                            'new' => 'Новый',
                            'confirmed' => 'Подтвержден',
                            'rejected' => 'Отклонен',
                            'paid' => 'Оплачен',
                            'completed' => 'Завершен'
                        ];
                        echo $status_labels[$booking['status']] ?? $booking['status'];
                        ?>
                    </p>
                    <p><strong>Дата создания:</strong> <?php echo date('d.m.Y H:i', strtotime($booking['created_at'])); ?></p>
                    <p><strong>Менеджер:</strong> <?php echo $booking['manager_name'] ? htmlspecialchars($booking['manager_name']) : 'Не назначен'; ?></p>
                </div>
            </div>

            <!-- Блок переписки -->
            <div class="messages-section">
                <h3>Переписка по бронированию</h3>
                
                <div class="messages-list">
                    <?php if (count($messages) > 0): ?>
                        <?php foreach ($messages as $message): ?>
                            <div class="message <?php echo $message['user_id'] == $user_id ? 'own-message' : ''; ?>">
                                <div class="message-header">
                                    <strong><?php echo htmlspecialchars($message['sender_name']); ?></strong>
                                    <span class="message-time"><?php echo date('d.m.Y H:i', strtotime($message['sent_at'])); ?></span>
                                </div>
                                <div class="message-text">
                                    <?php echo nl2br(htmlspecialchars($message['message_text'])); ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>Сообщений нет.</p>
                    <?php endif; ?>
                </div>
                
                <!-- Форма отправки сообщения -->
                <form method="POST" class="message-form">
                    <textarea name="message_text" rows="3" placeholder="Введите ваше сообщение..." required></textarea>
                    <button type="submit" name="send_message" class="btn btn-primary">Отправить сообщение</button>
                </form>
            </div>

            <!-- Блок платежей (только для менеджера и админа) -->
            <?php if ($user_role == 'manager' || $user_role == 'admin'): ?>
            <div class="payments-section">
                <h3>Платежи</h3>
                <?php if (count($payments) > 0): ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Сумма</th>
                                <th>Способ оплаты</th>
                                <th>Статус</th>
                                <th>Дата</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($payments as $payment): ?>
                                <tr>
                                    <td><?php echo $payment['id']; ?></td>
                                    <td><?php echo number_format($payment['amount'], 0, ',', ' '); ?> ₽</td>
                                    <td>
                                        <?php 
                                        $method_labels = [
                                            'card' => 'Карта',
                                            'cash' => 'Наличные',
                                            'bank_transfer' => 'Банковский перевод'
                                        ];
                                        echo $method_labels[$payment['payment_method']] ?? $payment['payment_method'];
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                        $status_labels = [
                                            'pending' => 'Ожидание',
                                            'completed' => 'Выполнен',
                                            'failed' => 'Ошибка',
                                            'refunded' => 'Возврат'
                                        ];
                                        echo $status_labels[$payment['status']] ?? $payment['status'];
                                        ?>
                                    </td>
                                    <td><?php echo date('d.m.Y H:i', strtotime($payment['created_at'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>Платежей нет.</p>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <!-- Кнопка возврата -->
            <div class="action-buttons">
                <a href="javascript:history.back()" class="btn btn-secondary">Назад</a>
                
                <?php if ($user_role == 'admin'): ?>
                    <a href="admin/bookings.php" class="btn btn-primary">К списку бронирований</a>
                <?php elseif ($user_role == 'manager'): ?>
                    <a href="manager/bookings.php" class="btn btn-primary">К списку бронирований</a>
                <?php elseif ($user_role == 'client'): ?>
                    <a href="client/my-bookings.php" class="btn btn-primary">К моим бронированиям</a>
                <?php endif; ?>
            </div>
        </main>
        
        <?php include 'includes/footer.php'; ?>
    </div>
</body>
</html>