<?php
session_start();
require_once '../config.php';
require_once '../includes/auth.php';

if (!isLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Бронирование тура
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_tour'])) {
    $tour_id = $_POST['tour_id'];
    $persons_count = $_POST['persons_count'];
    
    // Получаем информацию о туре
    $stmt = $pdo->prepare("SELECT price FROM tours WHERE id = ?");
    $stmt->execute([$tour_id]);
    $tour = $stmt->fetch();
    
    if ($tour) {
        $total_price = $tour['price'] * $persons_count;
        
        $stmt = $pdo->prepare("INSERT INTO bookings (user_id, tour_id, persons_count, total_price) VALUES (?, ?, ?, ?)");
        $stmt->execute([$user_id, $tour_id, $persons_count, $total_price]);
        $success = "Тур успешно забронирован!";
    } else {
        $error = "Тур не найден";
    }
}

// Поиск и фильтрация
$search = $_GET['search'] ?? '';
$country = $_GET['country'] ?? '';
$min_price = $_GET['min_price'] ?? '';
$max_price = $_GET['max_price'] ?? '';

// Получение уникальных стран для фильтра
$countries = $pdo->query("SELECT DISTINCT country FROM tours WHERE is_available = 1 ORDER BY country")->fetchAll();

// Формирование запроса с фильтрами
$query = "SELECT * FROM tours WHERE is_available = 1";
$params = [];

if ($search) {
    $query .= " AND (title LIKE ? OR description LIKE ? OR country LIKE ? OR city LIKE ?)";
    $search_term = "%$search%";
    $params = array_merge($params, [$search_term, $search_term, $search_term, $search_term]);
}

if ($country) {
    $query .= " AND country = ?";
    $params[] = $country;
}

if ($min_price) {
    $query .= " AND price >= ?";
    $params[] = $min_price;
}

if ($max_price) {
    $query .= " AND price <= ?";
    $params[] = $max_price;
}

$query .= " ORDER BY price ASC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$tours = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Туры - Улей</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .filters {
            background: var(--dark-gray);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .filter-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        .tour-card {
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .tour-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(255, 215, 0, 0.2);
        }
        .tour-features {
            display: flex;
            gap: 10px;
            margin: 10px 0;
        }
        .feature {
            background: rgba(255, 215, 0, 0.1);
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.9em;
        }
        .booking-form {
            display: none;
            margin-top: 15px;
            padding: 15px;
            background: rgba(0,0,0,0.1);
            border-radius: 5px;
        }
        .price-range {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .price-input {
            width: 100px;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php include '../includes/header.php'; ?>
        
        <main>
            <h2>Поиск туров</h2>
            
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <!-- Фильтры -->
            <div class="filters">
                <form method="GET" class="filter-form">
                    <div class="form-group">
                        <input type="text" name="search" class="form-control" 
                               placeholder="Поиск по названию или описанию"
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    
                    <div class="form-group">
                        <select name="country" class="form-control">
                            <option value="">Все страны</option>
                            <?php foreach ($countries as $c): ?>
                            <option value="<?php echo htmlspecialchars($c['country']); ?>" 
                                <?php echo $country == $c['country'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($c['country']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <div class="price-range">
                            <input type="number" name="min_price" class="form-control price-input" 
                                   placeholder="Мин. цена" value="<?php echo htmlspecialchars($min_price); ?>">
                            <span>-</span>
                            <input type="number" name="max_price" class="form-control price-input" 
                                   placeholder="Макс. цена" value="<?php echo htmlspecialchars($max_price); ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Применить фильтры</button>
                        <a href="tours.php" class="btn btn-secondary">Сбросить</a>
                    </div>
                </form>
            </div>
            
            <!-- Список туров -->
            <div class="tours-grid">
                <?php if (count($tours) > 0): ?>
                    <?php foreach ($tours as $tour): ?>
                    <div class="tour-card">
                        <div class="tour-header">
                            <h3><?php echo htmlspecialchars($tour['title']); ?></h3>
                            <span class="tour-price"><?php echo number_format($tour['price'], 0, ',', ' '); ?> ₽</span>
                        </div>
                        
                        <div class="tour-body">
                            <div class="tour-features">
                                <span class="feature">🌍 <?php echo htmlspecialchars($tour['country']); ?></span>
                                <span class="feature">🏙️ <?php echo htmlspecialchars($tour['city']); ?></span>
                                <?php if ($tour['start_date']): ?>
                                    <span class="feature">📅 <?php echo date('d.m.Y', strtotime($tour['start_date'])); ?></span>
                                <?php endif; ?>
                            </div>
                            
                            <p><?php echo htmlspecialchars(substr($tour['description'], 0, 150)); ?>...</p>
                            
                            <?php if ($tour['start_date'] && $tour['end_date']): ?>
                                <p><strong>Даты:</strong> <?php echo date('d.m.Y', strtotime($tour['start_date'])); ?> - <?php echo date('d.m.Y', strtotime($tour['end_date'])); ?></p>
                            <?php endif; ?>
                        </div>
                        
                        <div class="tour-footer">
                            <button class="btn btn-primary" onclick="showBookingForm(<?php echo $tour['id']; ?>)">
                                Забронировать
                            </button>
<a href="../tour_details.php?id=<?php echo $tour['id']; ?>" class="btn btn-secondary">
    Подробнее
</a>
                        </div>
                        
                        <!-- Форма бронирования (скрытая) -->
                        <div id="booking-form-<?php echo $tour['id']; ?>" class="booking-form">
                            <form method="POST">
                                <input type="hidden" name="tour_id" value="<?php echo $tour['id']; ?>">
                                
                                <div class="form-group">
                                    <label>Количество человек:</label>
                                    <input type="number" name="persons_count" class="form-control" 
                                           min="1" max="10" value="1" required>
                                </div>
                                
                                <div class="form-group">
                                    <label>Общая стоимость:</label>
                                    <input type="text" class="form-control" 
                                           value="<?php echo number_format($tour['price'], 0, ',', ' '); ?> ₽" 
                                           readonly id="total-price-<?php echo $tour['id']; ?>">
                                </div>
                                
                                <button type="submit" name="book_tour" class="btn btn-success">Подтвердить бронирование</button>
                                <button type="button" class="btn btn-secondary" onclick="hideBookingForm(<?php echo $tour['id']; ?>)">Отмена</button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="no-results">
                        <h3>Туры не найдены</h3>
                        <p>Попробуйте изменить параметры поиска</p>
                    </div>
                <?php endif; ?>
            </div>
        </main>
        
        <?php include '../includes/footer.php'; ?>
    </div>
    
    <script>
        function showBookingForm(tourId) {
            // Скрываем все формы
            document.querySelectorAll('.booking-form').forEach(form => {
                form.style.display = 'none';
            });
            
            // Показываем нужную форму
            const form = document.getElementById('booking-form-' + tourId);
            form.style.display = 'block';
            
            // Прокручиваем к форме
            form.scrollIntoView({ behavior: 'smooth' });
        }
        
        function hideBookingForm(tourId) {
            const form = document.getElementById('booking-form-' + tourId);
            form.style.display = 'none';
        }
        
        // Обновление цены при изменении количества человек
        document.addEventListener('input', function(e) {
            if (e.target.name === 'persons_count') {
                const tourId = e.target.form.querySelector('input[name="tour_id"]').value;
                const personsCount = e.target.value;
                
                // Здесь можно добавить AJAX запрос для расчета стоимости
                // Пока просто умножаем базовую цену на количество человек
                const basePrice = <?php echo json_encode(array_column($tours, 'price', 'id')); ?>;
                if (basePrice[tourId]) {
                    const totalPrice = basePrice[tourId] * personsCount;
                    document.getElementById('total-price-' + tourId).value = 
                        totalPrice.toLocaleString('ru-RU') + ' ₽';
                }
            }
        });
    </script>
</body>
</html>