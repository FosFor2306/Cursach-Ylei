<?php
session_start();
require_once '../config.php';
require_once '../includes/auth.php';

if (!isClient() && !isAdmin() && !isManager()) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Получаем бронирования пользователя
$stmt = $pdo->prepare("
    SELECT b.*, t.title as tour_title, t.country, t.city 
    FROM bookings b
    JOIN tours t ON b.tour_id = t.id
    WHERE b.user_id = ?
    ORDER BY b.created_at DESC
");
$stmt->execute([$user_id]);
$bookings = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мои бронирования - Улей</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <?php include '../includes/header.php'; ?>
        
        <main>
            <h2>Мои бронирования</h2>
            
            <?php if (count($bookings) == 0): ?>
                <p>У вас нет бронирований.</p>
                <a href="tours.php" class="btn btn-primary">Посмотреть туры</a>
            <?php else: ?>
                <table class="data-table">
<thead>
    <tr>
        <th>ID</th>
        <th>Тур</th>
        <th>Страна</th>
        <th>Город</th>
        <th>Кол-во человек</th>
        <th>Сумма</th>
        <th>Статус</th>
        <th>Дата создания</th>
        <th>Действия</th>
    </tr>
</thead>
<tbody>
    <?php foreach ($bookings as $booking): ?>
    <tr>
        <td><?php echo $booking['id']; ?></td>
        <td><?php echo htmlspecialchars($booking['tour_title']); ?></td>
        <td><?php echo htmlspecialchars($booking['country'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
        <td><?php echo htmlspecialchars($booking['city'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
        <td><?php echo isset($booking['persons_count']) && $booking['persons_count'] !== '' ? $booking['persons_count'] : 0; ?></td>
        <td><?php echo number_format($booking['total_price'], 0, ',', ' '); ?> ₽</td>
        <td>
            <?php 
            $status_labels = [
                'new' => 'Новый',
                'confirmed' => 'Подтвержден',
                'rejected' => 'Отклонен',
                'paid' => 'Оплачен',
                'completed' => 'Завершен'
            ];
            echo $status_labels[$booking['status']] ?? $booking['status'];
            ?>
        </td>
        <td><?php echo date('d.m.Y H:i', strtotime($booking['created_at'])); ?></td>
        <td>
            <a href="../booking_details.php?id=<?php echo $booking['id']; ?>" class="btn btn-sm btn-secondary">Подробнее</a>
        </td>
    </tr>
    <?php endforeach; ?>
</tbody>
                </table>
            <?php endif; ?>
        </main>
        
        <?php include '../includes/footer.php'; ?>
    </div>
</body>
</html>