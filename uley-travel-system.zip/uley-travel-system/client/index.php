<?php
session_start();
require_once '../config.php';
require_once '../includes/auth.php';

if (!isClient() && !isAdmin() && !isManager()) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Получаем статистику клиента
$stmt = $pdo->prepare("SELECT COUNT(*) as count FROM bookings WHERE user_id = ?");
$stmt->execute([$user_id]);
$my_bookings = $stmt->fetch()['count'];

$stmt = $pdo->prepare("SELECT COUNT(*) as count FROM reviews WHERE user_id = ?");
$stmt->execute([$user_id]);
$my_reviews = $stmt->fetch()['count'];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет клиента - Улей</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <?php include '../includes/header.php'; ?>
        
        <main>
            <h2>Личный кабинет клиента</h2>
            
            <div class="dashboard-grid">
                <div class="dashboard-card">
                    <h3>Моя статистика</h3>
                    <div class="stat">Мои бронирования: <span class="stat-number"><?php echo $my_bookings; ?></span></div>
                    <div class="stat">Мои отзывы: <span class="stat-number"><?php echo $my_reviews; ?></span></div>
                </div>
                
                <div class="dashboard-card">
                    <h3>Быстрые действия</h3>
                    <div class="quick-actions">
                        <a href="tours.php" class="btn btn-secondary btn-block">Смотреть туры</a>
                        <a href="my-bookings.php" class="btn btn-secondary btn-block">Мои бронирования</a>
                        <a href="../dashboard.php" class="btn btn-primary btn-block">Общий дашборд</a>
                    </div>
                </div>
            </div>
        </main>
        
        <?php include '../includes/footer.php'; ?>
    </div>
</body>
</html>