<?php
session_start();
require_once 'config.php';

// Проверяем авторизацию
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Получаем ID тура из GET параметра
$tour_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($tour_id == 0) {
    die("Не указан идентификатор тура");
}

// Получаем информацию о туре
$stmt = $pdo->prepare("
    SELECT t.*, 
           u.full_name as manager_name,
           COUNT(r.id) as reviews_count,
           AVG(r.rating) as avg_rating
    FROM tours t
    LEFT JOIN users u ON t.created_by = u.id
    LEFT JOIN bookings b ON t.id = b.tour_id AND b.status = 'completed'
    LEFT JOIN reviews r ON b.id = r.booking_id
    WHERE t.id = ?
    GROUP BY t.id
");
$stmt->execute([$tour_id]);
$tour = $stmt->fetch();

if (!$tour) {
    die("Тур не найден");
}

// Получаем отзывы к этому туру
$reviews_stmt = $pdo->prepare("
    SELECT r.*, u.full_name as user_name
    FROM reviews r
    JOIN bookings b ON r.booking_id = b.id
    JOIN users u ON r.user_id = u.id
    WHERE b.tour_id = ? AND r.is_approved = 1
    ORDER BY r.created_at DESC
    LIMIT 10
");
$reviews_stmt->execute([$tour_id]);
$reviews = $reviews_stmt->fetchAll();

// Получаем похожие туры (по стране)
$similar_stmt = $pdo->prepare("
    SELECT * FROM tours 
    WHERE country = ? AND id != ? AND is_available = 1 
    ORDER BY RANDOM() 
    LIMIT 3
");
$similar_stmt->execute([$tour['country'], $tour_id]);
$similar_tours = $similar_stmt->fetchAll();

// Бронирование тура (только для клиентов)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_tour']) && $user_role == 'client') {
    $persons_count = intval($_POST['persons_count']);
    
    if ($persons_count > 0) {
        $total_price = $tour['price'] * $persons_count;
        
        // Вставляем бронирование
        $stmt = $pdo->prepare("
            INSERT INTO bookings (user_id, tour_id, persons_count, total_price, status) 
            VALUES (?, ?, ?, ?, 'new')
        ");
        $stmt->execute([$user_id, $tour_id, $persons_count, $total_price]);
        
        $booking_id = $pdo->lastInsertId();
        
        // Перенаправляем на страницу бронирования
        header("Location: booking_details.php?id=" . $booking_id);
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($tour['title']); ?> - Улей</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .tour-hero {
            position: relative;
            background: linear-gradient(135deg, #1a237e 0%, #311b92 100%);
            padding: 40px;
            border-radius: 15px;
            margin-bottom: 30px;
            color: white;
        }
        
        .tour-hero h1 {
            color: white;
            border-bottom: 2px solid #bb86fc;
        }
        
        .tour-price-large {
            font-size: 36px;
            font-weight: bold;
            color: #bb86fc;
        }
        
        .tour-meta {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            margin: 20px 0;
        }
        
        .meta-item {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 15px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
        }
        
        .tour-content {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
            margin-bottom: 40px;
        }
        
        .tour-description {
            background: #2d2d2d;
            padding: 25px;
            border-radius: 10px;
            border: 1px solid #444;
        }
        
        .tour-info {
            background: #2d2d2d;
            padding: 25px;
            border-radius: 10px;
            border: 1px solid #444;
        }
        
        .booking-form {
            background: #1e1e1e;
            padding: 25px;
            border-radius: 10px;
            border: 2px solid #4285f4;
            margin-top: 30px;
        }
        
        .review-card {
            background: #2d2d2d;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 15px;
            border-left: 4px solid #bb86fc;
        }
        
        .review-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .review-rating {
            color: #ffd700;
        }
        
        .similar-tour {
            background: #2d2d2d;
            padding: 20px;
            border-radius: 8px;
            transition: transform 0.3s;
        }
        
        .similar-tour:hover {
            transform: translateY(-5px);
        }
        
        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        
        .persons-counter {
            display: flex;
            align-items: center;
            gap: 15px;
            margin: 20px 0;
        }
        
        .counter-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #4285f4;
            color: white;
            border: none;
            font-size: 20px;
            cursor: pointer;
        }
        
        .counter-input {
            width: 60px;
            text-align: center;
            font-size: 20px;
            font-weight: bold;
            background: transparent;
            border: none;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php include 'includes/header.php'; ?>
        
        <main>
            <!-- Герой-секция тура -->
            <div class="tour-hero">
                <h1><?php echo htmlspecialchars($tour['title']); ?></h1>
                <div class="tour-price-large">
                    <?php echo number_format($tour['price'], 0, ',', ' '); ?> ₽
                    <span style="font-size: 18px; color: #ccc;">за человека</span>
                </div>
                
                <div class="tour-meta">
                    <div class="meta-item">
                        <span>🌍</span>
                        <strong>Страна:</strong> <?php echo htmlspecialchars($tour['country']); ?>
                    </div>
                    <div class="meta-item">
                        <span>🏙️</span>
                        <strong>Город:</strong> <?php echo htmlspecialchars($tour['city']); ?>
                    </div>
                    <div class="meta-item">
                        <span>📅</span>
                        <strong>Даты:</strong> 
                        <?php echo date('d.m.Y', strtotime($tour['start_date'])); ?> - <?php echo date('d.m.Y', strtotime($tour['end_date'])); ?>
                    </div>
                    <div class="meta-item">
                        <span>⭐</span>
                        <strong>Рейтинг:</strong> 
                        <?php 
                        $avg_rating = $tour['avg_rating'] ? round($tour['avg_rating'], 1) : 'Нет оценок';
                        echo $avg_rating . '/5';
                        ?>
                    </div>
                    <div class="meta-item">
                        <span>👥</span>
                        <strong>Отзывы:</strong> <?php echo $tour['reviews_count'] ?: 0; ?>
                    </div>
                </div>
            </div>
            
            <!-- Основной контент -->
            <div class="tour-content">
                <div>
                    <div class="tour-description">
                        <h3>Описание тура</h3>
                        <p style="white-space: pre-line;"><?php echo nl2br(htmlspecialchars($tour['description'])); ?></p>
                    </div>
                    
                    <!-- Отзывы -->
                    <?php if (count($reviews) > 0): ?>
                    <div class="tour-description" style="margin-top: 20px;">
                        <h3>Отзывы путешественников</h3>
                        <?php foreach ($reviews as $review): ?>
                            <div class="review-card">
                                <div class="review-header">
                                    <strong><?php echo htmlspecialchars($review['user_name']); ?></strong>
                                    <div class="review-rating">
                                        <?php 
                                        for ($i = 1; $i <= 5; $i++): 
                                            echo $i <= $review['rating'] ? '★' : '☆';
                                        endfor; 
                                        ?>
                                    </div>
                                </div>
                                <p><?php echo nl2br(htmlspecialchars($review['comment'])); ?></p>
                                <small style="color: #9e9e9e;">
                                    <?php echo date('d.m.Y', strtotime($review['created_at'])); ?>
                                </small>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div>
                    <!-- Информация о туре -->
                    <div class="tour-info">
                        <h3>Детали тура</h3>
                        <p><strong>🎯 Тип отдыха:</strong> Пляжный/Экскурсионный</p>
                        <p><strong>📋 Включено в стоимость:</strong></p>
                        <ul>
                            <li>Проживание в отеле</li>
                            <li>Питание по программе</li>
                            <li>Трансфер из аэропорта</li>
                            <li>Медицинская страховка</li>
                            <li>Экскурсии по программе</li>
                        </ul>
                        <p><strong>👨‍💼 Менеджер тура:</strong> <?php echo htmlspecialchars($tour['manager_name']); ?></p>
                        <p><strong>📞 Контакты:</strong> +7 (XXX) XXX-XX-XX</p>
                    </div>
                    
                    <!-- Форма бронирования (только для клиентов) -->
                    <?php if ($user_role == 'client'): ?>
                    <div class="booking-form">
                        <h3>Забронировать тур</h3>
                        <form method="POST" id="bookingForm">
                            <div class="persons-counter">
                                <button type="button" class="counter-btn" onclick="changePersons(-1)">-</button>
                                <input type="number" name="persons_count" id="persons_count" 
                                       class="counter-input" value="1" min="1" max="10" readonly>
                                <button type="button" class="counter-btn" onclick="changePersons(1)">+</button>
                                <span>человек</span>
                            </div>
                            
                            <div style="margin: 20px 0;">
                                <p><strong>Стоимость за человека:</strong> 
                                   <span id="price_per_person"><?php echo number_format($tour['price'], 0, ',', ' '); ?></span> ₽</p>
                                <p><strong>Общая стоимость:</strong> 
                                   <span id="total_price" style="color: #bb86fc; font-size: 24px;">
                                       <?php echo number_format($tour['price'], 0, ',', ' '); ?>
                                   </span> ₽</p>
                            </div>
                            
                            <button type="submit" name="book_tour" class="btn btn-primary" style="width: 100%; padding: 15px;">
                                Забронировать сейчас
                            </button>
                        </form>
                        
                        <p style="margin-top: 15px; font-size: 12px; color: #9e9e9e; text-align: center;">
                            Нажимая кнопку, вы соглашаетесь с условиями бронирования
                        </p>
                    </div>
                    <?php elseif ($user_role == 'manager' || $user_role == 'admin'): ?>
                        <div class="tour-info" style="margin-top: 20px; text-align: center;">
                            <h3>Управление туром</h3>
                            <a href="admin/tours.php?edit=<?php echo $tour['id']; ?>" class="btn btn-primary">
                                Редактировать тур
                            </a>
                            <?php if ($tour['is_available']): ?>
                                <a href="admin/tours.php?deactivate=<?php echo $tour['id']; ?>" class="btn btn-secondary" 
                                   onclick="return confirm('Отключить тур?')">
                                    Отключить
                                </a>
                            <?php else: ?>
                                <a href="admin/tours.php?activate=<?php echo $tour['id']; ?>" class="btn btn-success">
                                    Активировать
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="tour-info" style="margin-top: 20px; text-align: center;">
                            <h3>Для бронирования</h3>
                            <p>Войдите как клиент, чтобы забронировать этот тур.</p>
                            <a href="login.php" class="btn btn-primary">Войти</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Похожие туры -->
            <?php if (count($similar_tours) > 0): ?>
            <div class="tour-description">
                <h3>Похожие туры</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                    <?php foreach ($similar_tours as $similar): ?>
                        <div class="similar-tour">
                            <h4><?php echo htmlspecialchars($similar['title']); ?></h4>
                            <p><strong>Страна:</strong> <?php echo htmlspecialchars($similar['country']); ?></p>
                            <p><strong>Цена:</strong> <?php echo number_format($similar['price'], 0, ',', ' '); ?> ₽</p>
                            <p style="height: 60px; overflow: hidden;"><?php echo substr(htmlspecialchars($similar['description']), 0, 100); ?>...</p>
                            <a href="tour_details.php?id=<?php echo $similar['id']; ?>" class="btn btn-secondary btn-sm">
                                Подробнее
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Кнопки действий -->
            <div class="action-buttons">
                <a href="javascript:history.back()" class="btn btn-secondary">Назад к списку</a>
                
                <?php if ($user_role == 'client'): ?>
                    <a href="client/my-bookings.php" class="btn btn-primary">Мои бронирования</a>
                <?php elseif ($user_role == 'admin'): ?>
                    <a href="admin/tours.php" class="btn btn-primary">Управление турами</a>
                <?php elseif ($user_role == 'manager'): ?>
                    <a href="../manager/bookings.php" class="btn btn-primary">К бронированиям</a>
                <?php endif; ?>
            </div>
        </main>
        
        <?php include 'includes/footer.php'; ?>
    </div>
    
    <script>
        const basePrice = <?php echo $tour['price']; ?>;
        
        function changePersons(change) {
            const input = document.getElementById('persons_count');
            let value = parseInt(input.value) + change;
            
            if (value < 1) value = 1;
            if (value > 10) value = 10;
            
            input.value = value;
            updateTotalPrice();
        }
        
        function updateTotalPrice() {
            const persons = parseInt(document.getElementById('persons_count').value);
            const total = basePrice * persons;
            
            document.getElementById('total_price').textContent = 
                total.toLocaleString('ru-RU') + ' ₽';
        }
        
        // Инициализация
        updateTotalPrice();
        
        // Обновление при ручном вводе
        document.getElementById('persons_count').addEventListener('change', updateTotalPrice);
    </script>
</body>
</html>