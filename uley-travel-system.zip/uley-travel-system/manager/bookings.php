<?php
session_start();
require_once '../config.php';
require_once '../includes/auth.php';

// Проверяем существование функций авторизации
if (function_exists('isAdmin') && function_exists('isManager')) {
    if (!isAdmin() && !isManager()) {
        // Проверяем, не были ли уже отправлены заголовки
        if (!headers_sent()) {
            header("Location: ../login.php?error=access_denied");
        }
        exit();
    }
} else {
    // Если функции не определены, перенаправляем на логин
    if (!headers_sent()) {
        header("Location: ../login.php?error=auth_error");
    }
    exit();
}


$user_id = $_SESSION['user_id'];

// Обновление статуса бронирования
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $booking_id = $_POST['booking_id'];
    $status = $_POST['status'];
    
    $stmt = $pdo->prepare("UPDATE bookings SET status = ?, manager_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
    $stmt->execute([$status, $user_id, $booking_id]);
    $success = "Статус бронирования обновлен";
}

// Получаем бронирования, назначенные менеджеру (или все, если админ)
if (isAdmin()) {
    $bookings = $pdo->query("
        SELECT b.*, u.full_name as user_name, t.title as tour_title 
        FROM bookings b
        JOIN users u ON b.user_id = u.id
        JOIN tours t ON b.tour_id = t.id
        ORDER BY b.created_at DESC
    ")->fetchAll();
} else {
    $stmt = $pdo->prepare("
        SELECT b.*, u.full_name as user_name, t.title as tour_title 
        FROM bookings b
        JOIN users u ON b.user_id = u.id
        JOIN tours t ON b.tour_id = t.id
        WHERE b.manager_id = ? OR b.manager_id IS NULL
        ORDER BY b.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $bookings = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Бронирования - Панель менеджера - Улей</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <?php include '../includes/header.php'; ?>
        
        <main>
            <h2>Управление бронированиями</h2>
            
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Клиент</th>
                        <th>Тур</th>
                        <th>Кол-во человек</th>
                        <th>Сумма</th>
                        <th>Статус</th>
                        <th>Дата создания</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($bookings as $booking): ?>
                    <tr>
                        <td><?php echo $booking['id']; ?></td>
                        <td><?php echo htmlspecialchars($booking['user_name']); ?></td>
                        <td><?php echo htmlspecialchars($booking['tour_title']); ?></td>
                        <td><?php echo $booking['persons_count']; ?></td>
                        <td><?php echo number_format($booking['total_price'], 0, ',', ' '); ?> ₽</td>
                        <td>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                <select name="status" onchange="this.form.submit()">
                                    <option value="new" <?php echo $booking['status'] == 'new' ? 'selected' : ''; ?>>Новый</option>
                                    <option value="confirmed" <?php echo $booking['status'] == 'confirmed' ? 'selected' : ''; ?>>Подтвержден</option>
                                    <option value="rejected" <?php echo $booking['status'] == 'rejected' ? 'selected' : ''; ?>>Отклонен</option>
                                    <option value="paid" <?php echo $booking['status'] == 'paid' ? 'selected' : ''; ?>>Оплачен</option>
                                    <option value="completed" <?php echo $booking['status'] == 'completed' ? 'selected' : ''; ?>>Завершен</option>
                                </select>
                                <input type="hidden" name="update_status" value="1">
                            </form>
                        </td>
                        <td><?php echo date('d.m.Y H:i', strtotime($booking['created_at'])); ?></td>
<td>
    <a href="../booking_details.php?id=<?php echo $booking['id']; ?>" class="btn btn-sm btn-secondary">Подробнее</a>
</td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </main>
        
        <?php include '../includes/footer.php'; ?>
    </div>
</body>
</html>