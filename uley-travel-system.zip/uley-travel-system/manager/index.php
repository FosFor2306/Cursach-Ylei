<?php
session_start();
require_once '../config.php';
require_once '../includes/auth.php';

if (!isManager() && !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Получаем статистику для менеджера
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT COUNT(*) as count FROM bookings WHERE manager_id = ?");
$stmt->execute([$user_id]);
$my_bookings = $stmt->fetch()['count'];

$pending_messages = $pdo->query("SELECT COUNT(*) as count FROM messages WHERE is_read = 0")->fetch()['count'];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель менеджера - Улей</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <?php include '../includes/header.php'; ?>
        
        <main>
            <h2>Панель менеджера</h2>
            
            <div class="dashboard-grid">
                <div class="dashboard-card">
                    <h3>Статистика</h3>
                    <div class="stat">Мои бронирования: <span class="stat-number"><?php echo $my_bookings; ?></span></div>
                    <div class="stat">Новых сообщений: <span class="stat-number"><?php echo $pending_messages; ?></span></div>
                </div>
                
                <div class="dashboard-card">
                    <h3>Быстрые действия</h3>
                    <div class="quick-actions">
                        <a href="bookings.php" class="btn btn-secondary btn-block">Обработка бронирований</a>
                        <a href="messages.php" class="btn btn-secondary btn-block">Сообщения</a>
                        <a href="../dashboard.php" class="btn btn-primary btn-block">Общий дашборд</a>
                    </div>
                </div>
            </div>
        </main>
        
        <?php include '../includes/footer.php'; ?>
    </div>
</body>
</html>