<?php
session_start();
require_once '../config.php';
require_once '../includes/auth.php';

if (!isManager() && !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

$manager_id = $_SESSION['user_id'];

// Обработка отправки сообщения
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $booking_id = $_POST['booking_id'];
    $message_text = $_POST['message_text'];
    
    $stmt = $pdo->prepare("INSERT INTO messages (booking_id, user_id, message_text) VALUES (?, ?, ?)");
    $stmt->execute([$booking_id, $manager_id, $message_text]);
    $success = "Сообщение отправлено";
}

// Отметка как прочитанное
if (isset($_GET['mark_read'])) {
    $message_id = $_GET['mark_read'];
    $stmt = $pdo->prepare("UPDATE messages SET is_read = 1 WHERE id = ?");
    $stmt->execute([$message_id]);
}

// Получение сообщений
$messages = $pdo->query("
    SELECT m.*, u.full_name as sender_name, b.id as booking_id, t.title as tour_title
    FROM messages m
    LEFT JOIN users u ON m.user_id = u.id
    LEFT JOIN bookings b ON m.booking_id = b.id
    LEFT JOIN tours t ON b.tour_id = t.id
    ORDER BY m.sent_at DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Сообщения - Улей</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .messages-container {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-top: 20px;
        }
        .message-list {
            max-height: 600px;
            overflow-y: auto;
        }
        .message-item {
            background: var(--dark-gray);
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 5px;
            border-left: 4px solid var(--primary-yellow);
        }
        .message-item.unread {
            border-left-color: #ff4444;
            background: rgba(255, 68, 68, 0.1);
        }
        .message-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .message-sender {
            font-weight: bold;
            color: var(--primary-yellow);
        }
        .message-time {
            color: #888;
            font-size: 0.9em;
        }
        .message-booking {
            color: #aaa;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php include '../includes/header.php'; ?>
        
        <main>
            <h2>Управление сообщениями</h2>
            
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <div class="messages-container">
                <!-- Список сообщений -->
                <div class="message-list">
                    <h3>Все сообщения</h3>
                    
                    <?php if (count($messages) > 0): ?>
                        <?php foreach ($messages as $message): ?>
                        <div class="message-item <?php echo $message['is_read'] ? '' : 'unread'; ?>">
                            <div class="message-header">
                                <?php echo isset($message['sender_name']) ? htmlspecialchars($message['sender_name'], ENT_QUOTES, 'UTF-8') : 'Неизвестный отправитель'; ?>
                                <span class="message-time"><?php echo date('d.m.Y H:i', strtotime($message['sent_at'])); ?></span>
                            </div>
                            
                            <div class="message-booking">
                                Бронирование #<?php echo $message['booking_id']; ?> - <?php echo htmlspecialchars($message['tour_title']); ?>
                            </div>
                            
                            <div class="message-text">
                                <?php echo nl2br(htmlspecialchars($message['message_text'])); ?>
                            </div>
                            
                            <?php if (!$message['is_read'] && $message['user_id'] != $manager_id): ?>
                                <div class="message-actions">
                                    <a href="?mark_read=<?php echo $message['id']; ?>" class="btn btn-sm btn-secondary">Отметить как прочитанное</a>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-center">Сообщений нет</p>
                    <?php endif; ?>
                </div>
                
                <!-- Форма отправки сообщения -->
                <div>
                    <h3>Отправить сообщение</h3>
                    <div class="card">
                        <form method="POST">
                            <div class="form-group">
                                <label>Выберите бронирование:</label>
                                <select name="booking_id" class="form-control" required>
                                    <option value="">-- Выберите бронирование --</option>
                                    <?php
                                    $stmt = $pdo->query("
                                        SELECT b.id, u.full_name, t.title 
                                        FROM bookings b
                                        LEFT JOIN users u ON b.user_id = u.id
                                        LEFT JOIN tours t ON b.tour_id = t.id
                                        WHERE b.status IN ('new', 'confirmed')
                                        ORDER BY b.created_at DESC
                                    ");
                                    $bookings = $stmt->fetchAll();
                                    foreach ($bookings as $booking):
                                    ?>
                                    <option value="<?php echo $booking['id']; ?>">
                                        #<?php echo $booking['id']; ?> - <?php echo htmlspecialchars($booking['full_name']); ?> (<?php echo htmlspecialchars($booking['title']); ?>)
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>Сообщение:</label>
                                <textarea name="message_text" class="form-control" rows="5" required 
                                          placeholder="Введите текст сообщения..."></textarea>
                            </div>
                            
                            <button type="submit" name="send_message" class="btn btn-primary btn-block">Отправить сообщение</button>
                        </form>
                    </div>
                    
                    <!-- Статистика -->
                    <div class="card mt-3">
                        <h4>Статистика сообщений</h4>
                        <?php
                        $total_messages = $pdo->query("SELECT COUNT(*) as count FROM messages")->fetch()['count'];
                        $unread_messages = $pdo->query("SELECT COUNT(*) as count FROM messages WHERE is_read = 0")->fetch()['count'];
                        $today_messages = $pdo->query("SELECT COUNT(*) as count FROM messages WHERE DATE(sent_at) = DATE('now')")->fetch()['count'];
                        ?>
                        <div class="stats">
                            <div class="stat-item">
                                <span>Всего сообщений:</span>
                                <span class="stat-value"><?php echo $total_messages; ?></span>
                            </div>
                            <div class="stat-item">
                                <span>Непрочитанных:</span>
                                <span class="stat-value"><?php echo $unread_messages; ?></span>
                            </div>
                            <div class="stat-item">
                                <span>Сегодня:</span>
                                <span class="stat-value"><?php echo $today_messages; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        
        <?php include '../includes/footer.php'; ?>
    </div>
</body>
</html>